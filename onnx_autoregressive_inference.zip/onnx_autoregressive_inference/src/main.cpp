/**
 * ONNX Runtime Transformer 自回归推理程序（带 KV Cache 管理）
 *
 * 适用于语音转文字、文本生成等自回归任务
 * 支持：
 * - KV Cache 管理
 * - 贪心搜索和束搜索
 * - 批量生成
 * - 流式推理
 */

#include <iostream>
#include <vector>
#include <string>
#include <memory>
#include <chrono>
#include <algorithm>
#include <numeric>
#include <cmath>
#include <random>
#include <onnxruntime_cxx_api.h>

// ============================================================================
// 配置结构体
// ============================================================================

struct InferenceConfig {
    // 生成参数
    int maxLength = 100;           // 最大生成长度
    int batchSize = 1;              // 批大小
    float temperature = 1.0f;       // 温度参数
    int topK = 0;                   // Top-K 采样 (0 = 禁用)
    float topP = 1.0f;              // Top-P (Nucleus) 采样
    float repeatPenalty = 1.0f;    // 重复惩罚

    // KV Cache 配置
    int maxCacheLength = 512;      // 最大缓存长度

    // 解码方式
    enum class DecodingStrategy {
        Greedy,       // 贪心搜索
        BeamSearch,   // 束搜索
        Sampling      // 采样
    };
    DecodingStrategy strategy = DecodingStrategy::Greedy;
    int beamSize = 1;               // 束搜索宽度
};

// ============================================================================
// 工具函数
// ============================================================================

class TensorUtils {
public:
    // 打印形状
    static void printShape(const std::string& name, const std::vector<int64_t>& shape) {
        std::cout << name << " Shape: [";
        for (size_t i = 0; i < shape.size(); ++i) {
            std::cout << shape[i];
            if (i < shape.size() - 1) std::cout << ", ";
        }
        std::cout << "]\n";
    }

    // 创建随机输入（模拟）
    static std::vector<float> createRandomInput(int64_t size) {
        std::vector<float> data(size);
        std::random_device rd;
        std::mt19937 gen(rd());
        std::uniform_real_distribution<> dis(0.0, 1.0);
        for (auto& val : data) {
            val = static_cast<float>(dis(gen));
        }
        return data;
    }

    // Softmax 函数
    static std::vector<float> softmax(const std::vector<float>& input) {
        std::vector<float> output(input.size());
        float maxVal = *std::max_element(input.begin(), input.end());
        float sum = 0.0f;

        for (size_t i = 0; i < input.size(); ++i) {
            output[i] = std::exp(input[i] - maxVal);
            sum += output[i];
        }

        for (size_t i = 0; i < output.size(); ++i) {
            output[i] /= sum;
        }

        return output;
    }

    // Top-K 过滤
    static std::vector<float> topKFilter(std::vector<float>& logits, int topK) {
        if (topK <= 0 || topK >= static_cast<int>(logits.size())) {
            return logits;
        }

        // 找到 Top-K 的阈值
        std::vector<float> sorted = logits;
        std::partial_sort_copy(logits.begin(), logits.end(),
                               sorted.begin(), sorted.end(),
                               std::greater<float>());
        float threshold = sorted[topK];

        // 过滤
        for (auto& val : logits) {
            if (val < threshold) val = -1e9f;
        }
        return logits;
    }

    // Top-P (Nucleus) 过滤
    static std::vector<float> topPFilter(std::vector<float>& logits, float topP) {
        std::vector<int64_t> indices(logits.size());
        std::iota(indices.begin(), indices.end(), 0);

        // 按概率排序
        std::sort(indices.begin(), indices.end(),
            [&logits](int64_t a, int64_t b) {
                return logits[a] > logits[b];
            });

        float cumsum = 0.0f;
        for (size_t i = 0; i < indices.size(); ++i) {
            cumsum += logits[indices[i]];
            if (cumsum > topP) {
                // 屏蔽后面的词
                for (size_t j = i + 1; j < indices.size(); ++j) {
                    logits[indices[j]] = -1e9f;
                }
                break;
            }
        }

        return logits;
    }

    // 应用重复惩罚
    static void applyRepeatPenalty(std::vector<float>& logits,
                                   const std::vector<int>& previouslyGenerated,
                                   float penalty) {
        if (penalty == 1.0f || previouslyGenerated.empty()) return;

        for (int tokenId : previouslyGenerated) {
            if (logits[tokenId] < 0) {
                logits[tokenId] *= penalty;
            } else {
                logits[tokenId] /= penalty;
            }
        }
    }
};

// ============================================================================
// KV Cache 管理器
// ============================================================================

class KVCacheManager {
private:
    OrtEnv& env_;
    std::unique_ptr<OrtSession> session_;
    OrtMemoryInfo* memoryInfo_;

    // Cache 状态
    std::vector<int64_t> pastKeyShape_;
    std::vector<int64_t> pastValueShape_;
    std::vector<float> pastKeyCache_;
    std::vector<float> pastValueCache_;
    int currentCacheLength_ = 0;

    // 模型配置
    int numLayers_;
    int numHeads_;
    int headDim_;
    int vocabSize_;

public:
    KVCacheManager(OrtEnv& env, const std::string& modelPath)
        : env_(env), memoryInfo_(nullptr) {

        // 创建会话选项
        OrtSessionOptions* sessionOptions = api.CreateSessionOptions();
        sessionOptions->SetGraphOptimizationLevel(GraphOptimizationLevel::ORT_ENABLE_ALL);

        // 加载模型
        session_ = std::unique_ptr<OrtSession>(api.CreateSession(env, modelPath.c_str(), sessionOptions));
        api.ReleaseSessionOptions(sessionOptions);

        // 创建内存 Info
        memoryInfo_ = api.CreateMemoryInfo(OrtArenaAllocator, OrtMemTypeDefault);

        // 获取模型配置信息
        extractModelConfig();

        // 初始化 KV Cache
        initializeCache();

        std::cout << "KV Cache 管理器初始化完成\n";
        std::cout << "  - 层数: " << numLayers_ << "\n";
        std::cout << "  - 头数: " << numHeads_ << "\n";
        std::cout << "  - Head 维度: " << headDim_ << "\n";
        std::cout << "  - 词表大小: " << vocabSize_ << "\n\n";
    }

    ~KVCacheManager() {
        if (memoryInfo_) {
            api.ReleaseMemoryInfo(memoryInfo_);
        }
    }

private:
    void extractModelConfig() {
        // 这里需要根据实际模型结构调整
        // 通常从模型的输入输出形状推断
        numLayers_ = 12;      // 默认值，需要根据模型修改
        numHeads_ = 12;
        headDim_ = 64;
        vocabSize_ = 50000;
    }

    void initializeCache() {
        // 初始化 KV Cache 形状
        // 形状: [batch, num_heads, seq_len, head_dim]
        pastKeyShape_ = {1, numHeads_, 0, headDim_};
        pastValueShape_ = {1, numHeads_, 0, headDim_};

        // 初始缓存为空
        pastKeyCache_.clear();
        pastValueCache_.clear();
        currentCacheLength_ = 0;
    }

public:
    // 重置 Cache（用于新的生成任务）
    void reset() {
        initializeCache();
        std::cout << "KV Cache 已重置\n";
    }

    // 更新 Cache（增量推理）
    void updateCache(const std::vector<float>& newKeys,
                     const std::vector<float>& newValues,
                     int seqLen) {

        // 扩展缓存
        size_t layerSize = numHeads_ * seqLen * headDim_;

        for (size_t i = 0; i < newKeys.size(); i += layerSize) {
            pastKeyCache_.insert(pastKeyCache_.end(),
                                newKeys.begin() + i,
                                newKeys.begin() + i + layerSize);
            pastValueCache_.insert(pastValueCache_.end(),
                                  newValues.begin() + i,
                                  newValues.begin() + i + layerSize);
        }

        currentCacheLength_ += seqLen;
    }

    // 执行一步推理
    std::vector<float> stepInference(const std::vector<float>& inputIds,
                                      const std::vector<float>& attentionMask,
                                      const InferenceConfig& config) {

        // 准备输入
        // 注意：实际模型可能使用不同的输入名称和格式
        std::vector<OrtValue*> inputTensors;

        // 1. input_ids (当前 token)
        int64_t inputSize = inputIds.size();
        OrtValue* inputTensor = api.CreateTensorWithDataAsOrtValue(
            memoryInfo_,
            const_cast<float*>(inputIds.data()),
            inputSize * sizeof(float),
            &inputSize,
            1,
            ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT
        );
        inputTensors.push_back(inputTensor);

        // 2. attention_mask
        OrtValue* maskTensor = api.CreateTensorWithDataAsOrtValue(
            memoryInfo_,
            const_cast<float*>(attentionMask.data()),
            attentionMask.size() * sizeof(float),
            &inputSize,
            1,
            ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT
        );
        inputTensors.push_back(maskTensor);

        // 3. past_key_values (KV Cache) - 如果模型支持
        // 这里简化处理，实际需要根据模型结构调整

        // 设置输入输出名称
        std::vector<const char*> inputNames = {"input_ids", "attention_mask"};
        std::vector<const char*> outputNames = {"logits", "present_key", "present_value"};

        // 运行推理
        std::vector<OrtValue*> outputTensors;
        session_->Run(
            OrtRunOptions{nullptr},
            inputNames.data(),
            inputTensors.data(),
            inputTensors.size(),
            outputNames.data(),
            outputNames.size()
        );

        // 提取 logits
        float* logitsData = api.GetOrtValueTensorData(
            outputTensors[0],
            ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT
        );

        // vocabSize 维度的 logits
        std::vector<float> logits(logitsData, logitsData + vocabSize_);

        // 如果模型返回了新的 KV Cache，更新缓存
        if (outputTensors.size() > 1) {
            // 更新逻辑需要根据实际模型输出调整
        }

        // 释放资源
        for (auto* tensor : inputTensors) {
            api.ReleaseValue(tensor);
        }
        for (auto* tensor : outputTensors) {
            api.ReleaseValue(tensor);
        }

        return logits;
    }
};

// ============================================================================
// 自回归生成器
// ============================================================================

class AutoregressiveGenerator {
private:
    OrtEnv& env_;
    std::unique_ptr<OrtSession> session_;
    std::unique_ptr<OrtSessionOptions> sessionOptions_;
    OrtMemoryInfo* memoryInfo_;

    // 模型信息
    std::vector<int64_t> inputIdsShape_;
    std::vector<int64_t> attentionMaskShape_;
    std::vector<int64_t> logitsShape_;

    // 词表
    int vocabSize_;
    int maxLength_;

    // 特殊 token ID
    int padTokenId_ = 0;
    int eosTokenId_ = 2;
    int bosTokenId_ = 1;

public:
    AutoregressiveGenerator(OrtEnv& env, const std::string& modelPath,
                           const InferenceConfig& config)
        : env_(env), maxLength_(config.maxLength) {

        // 创建会话选项
        sessionOptions_ = std::unique_ptr<OrtSessionOptions>(api.CreateSessionOptions());
        sessionOptions_->SetGraphOptimizationLevel(GraphOptimizationLevel::ORT_ENABLE_ALL);
        sessionOptions_->SetIntraOpNumThreads(4);

        // 加载模型
        session_ = std::unique_ptr<OrtSession>(
            api.CreateSession(env, modelPath.c_str(), sessionOptions_.get())
        );

        // 创建内存 Info
        memoryInfo_ = api.CreateMemoryInfo(OrtArenaAllocator, OrtMemTypeDefault);

        // 获取模型信息
        extractModelInfo();

        std::cout << "自回归生成器初始化完成\n";
        std::cout << "  - 词表大小: " << vocabSize_ << "\n";
        std::cout << "  - 最大长度: " << maxLength_ << "\n";
        std::cout << "  - 解码策略: ";
        switch (config.strategy) {
            case InferenceConfig::DecodingStrategy::Greedy:
                std::cout << "贪心搜索\n"; break;
            case InferenceConfig::DecodingStrategy::BeamSearch:
                std::cout << "束搜索 (width=" << config.beamSize << ")\n"; break;
            case InferenceConfig::DecodingStrategy::Sampling:
                std::cout << "采样\n"; break;
        }
        std::cout << "\n";
    }

    ~AutoregressiveGenerator() {
        if (memoryInfo_) {
            api.ReleaseMemoryInfo(memoryInfo_);
        }
    }

private:
    void extractModelInfo() {
        // 从模型获取输入输出信息
        size_t inputCount = session_->GetInputCount();
        size_t outputCount = session_->GetOutputCount();

        std::cout << "模型输入节点: " << inputCount << "\n";
        std::cout << "模型输出节点: " << outputCount << "\n";

        // 简化：使用默认值，实际应该从模型推断
        vocabSize_ = 50000;
        inputIdsShape_ = {1, 1};
        attentionMaskShape_ = {1, 1};
        logitsShape_ = {1, 1, vocabSize_};
    }

    // 单步推理
    std::vector<float> forwardStep(const std::vector<int>& inputIds,
                                   const std::vector<int>& attentionMask) {
        // 转换为 float
        std::vector<float> inputIdsF(inputIds.begin(), inputIds.end());
        std::vector<float> attentionMaskF(attentionMask.begin(), attentionMask.end());

        int64_t seqLen = inputIds.size();

        // 创建输入 tensors
        std::vector<OrtValue*> inputTensors;

        OrtValue* inputTensor = api.CreateTensorWithDataAsOrtValue(
            memoryInfo_,
            inputIdsF.data(),
            inputIdsF.size() * sizeof(float),
            &seqLen,
            1,
            ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT
        );
        inputTensors.push_back(inputTensor);

        OrtValue* maskTensor = api.CreateTensorWithDataAsOrtValue(
            memoryInfo_,
            attentionMaskF.data(),
            attentionMaskF.size() * sizeof(float),
            &seqLen,
            1,
            ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT
        );
        inputTensors.push_back(maskTensor);

        // 设置名称（需要根据实际模型调整）
        std::vector<const char*> inputNames = {"input_ids", "attention_mask"};
        std::vector<const char*> outputNames = {"logits"};

        // 运行推理
        std::vector<OrtValue*> outputTensors;
        session_->Run(
            OrtRunOptions{nullptr},
            inputNames.data(),
            inputTensors.data(),
            inputTensors.size(),
            outputNames.data(),
            outputNames.size()
        );

        // 提取 logits
        float* logitsData = api.GetOrtValueTensorData(
            outputTensors[0],
            ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT
        );

        std::vector<float> logits(logitsData, logitsData + vocabSize_);

        // 释放
        for (auto* t : inputTensors) api.ReleaseValue(t);
        for (auto* t : outputTensors) api.ReleaseValue(t);

        return logits;
    }

    // 贪心搜索解码
    int greedyDecode(const std::vector<float>& logits) {
        return std::max_element(logits.begin(), logits.end()) - logits.begin();
    }

    // 采样解码
    int sampleDecode(const std::vector<float>& logits, const InferenceConfig& config) {
        std::vector<float> processedLogits = logits;

        // 应用温度
        if (config.temperature != 1.0f) {
            for (auto& logit : processedLogits) {
                logit /= config.temperature;
            }
        }

        // Top-K 过滤
        if (config.topK > 0) {
            processedLogits = TensorUtils::topKFilter(processedLogits, config.topK);
        }

        // Top-P 过滤
        if (config.topP < 1.0f) {
            processedLogits = TensorUtils::topPFilter(processedLogits, config.topP);
        }

        // Softmax
        auto probs = TensorUtils::softmax(processedLogits);

        // 采样
        std::random_device rd;
        std::mt19937 gen(rd());
        std::uniform_real_distribution<> dis(0.0, 1.0);
        float r = dis(gen);

        float cumsum = 0.0f;
        for (size_t i = 0; i < probs.size(); ++i) {
            cumsum += probs[i];
            if (r <= cumsum) {
                return i;
            }
        }

        return probs.size() - 1;
    }

public:
    // 主生成函数
    std::vector<int> generate(const std::vector<int>& promptTokens,
                             const InferenceConfig& config) {

        std::cout << "开始自回归生成...\n";
        auto startTime = std::chrono::high_resolution_clock::now();

        // 初始化
        std::vector<int> generatedTokens;
        std::vector<int> currentInputIds = promptTokens;
        std::vector<int> currentAttentionMask(promptTokens.size(), 1);

        generatedTokens.reserve(maxLength_);

        // 迭代生成
        for (int step = 0; step < maxLength_; ++step) {
            // 前向传播
            auto logits = forwardStep(currentInputIds, currentAttentionMask);

            // 解码
            int nextToken;
            switch (config.strategy) {
                case InferenceConfig::DecodingStrategy::Greedy:
                case InferenceConfig::DecodingStrategy::BeamSearch:
                    nextToken = greedyDecode(logits);
                    break;
                case InferenceConfig::DecodingStrategy::Sampling:
                    nextToken = sampleDecode(logits, config);
                    break;
                default:
                    nextToken = greedyDecode(logits);
            }

            // 检查 EOS
            if (nextToken == eosTokenId_) {
                std::cout << "  [Step " << step << "] 遇到结束符\n";
                break;
            }

            // 添加到生成序列
            generatedTokens.push_back(nextToken);

            // 打印进度
            if (step % 10 == 0) {
                std::cout << "  [Step " << step << "] 生成 token: " << nextToken << "\n";
            }

            // 准备下一步输入
            currentInputIds = {nextToken};
            currentAttentionMask = {1};
        }

        auto endTime = std::chrono::high_resolution_clock::now();
        auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(endTime - startTime);

        std::cout << "\n生成完成!\n";
        std::cout << "  - 生成 token 数: " << generatedTokens.size() << "\n";
        std::cout << "  - 耗时: " << duration.count() << " ms\n";
        std::cout << "  - 平均延迟: " << (float)duration.count() / generatedTokens.size()
                  << " ms/token\n\n";

        return generatedTokens;
    }

    // 流式生成（带回调）
    template<typename Callback>
    void generateStream(const std::vector<int>& promptTokens,
                       const InferenceConfig& config,
                       Callback&& onTokenGenerated) {

        std::cout << "开始流式生成...\n";

        std::vector<int> currentInputIds = promptTokens;
        std::vector<int> currentAttentionMask(promptTokens.size(), 1);

        for (int step = 0; step < maxLength_; ++step) {
            auto logits = forwardStep(currentInputIds, currentAttentionMask);

            int nextToken;
            switch (config.strategy) {
                case InferenceConfig::DecodingStrategy::Greedy:
                    nextToken = greedyDecode(logits);
                    break;
                default:
                    nextToken = sampleDecode(logits, config);
            }

            if (nextToken == eosTokenId_) {
                break;
            }

            // 回调
            onTokenGenerated(nextToken, step);

            currentInputIds = {nextToken};
            currentAttentionMask = {1};
        }
    }
};

// ============================================================================
// 主函数
// ============================================================================

int main(int argc, char** argv) {
    try {
        const OrtApi& api = OrtGetApiBase()->GetApi(ORT_API_API_VERSION);

        std::cout << "========================================\n";
        std::cout << "  自回归 Transformer 推理系统\n";
        std::cout << "  (支持 KV Cache 和多种解码策略)\n";
        std::cout << "========================================\n\n";

        // 创建环境
        OrtEnv env(api, ORT_LOGGING_LEVEL_WARNING, "autoregressive_inference");

        // 模型路径
        std::string modelPath = "transformer_model.onnx";
        if (argc > 1) {
            modelPath = argv[1];
        }

        // 配置
        InferenceConfig config;
        config.maxLength = 100;
        config.batchSize = 1;
        config.temperature = 0.7f;
        config.topK = 50;
        config.topP = 0.9f;
        config.repeatPenalty = 1.1f;
        config.strategy = InferenceConfig::DecodingStrategy::Sampling;
        config.beamSize = 3;

        std::cout << "配置:\n";
        std::cout << "  - 模型: " << modelPath << "\n";
        std::cout << "  - 最大长度: " << config.maxLength << "\n";
        std::cout << "  - 温度: " << config.temperature << "\n";
        std::cout << "  - Top-K: " << config.topK << "\n";
        std::cout << "  - Top-P: " << config.topP << "\n";
        std::cout << "  - 重复惩罚: " << config.repeatPenalty << "\n\n";

        // 创建生成器
        AutoregressiveGenerator generator(env, modelPath, config);

        // 示例：使用语音特征作为输入（模拟）
        // 实际应用中，这里应该是声学模型的输出
        std::vector<int> promptTokens = {101};  // [BOS] token

        std::cout << "========================================\n";
        std::cout << "开始生成\n";
        std::cout << "========================================\n\n";

        // 方法1：批量生成
        auto result = generator.generate(promptTokens, config);

        // 方法2：流式生成
        std::cout << "\n流式输出: ";
        generator.generateStream(promptTokens, config,
            [](int token, int step) {
                std::cout << token << " ";
            });

        std::cout << "\n\n程序完成!\n";

    } catch (const OrtException& e) {
        std::cerr << "ONNX Runtime 错误: " << e.what() << "\n";
        return 1;
    } catch (const std::exception& e) {
        std::cerr << "错误: " << e.what() << "\n";
        return 1;
    }

    return 0;
}
