# MNN 开源推理框架技术调研报告

> 调研对象：MNN（Mobile Neural Network）— 阿里巴巴开源的端侧深度学习推理引擎
> 调研时间：2026-09 ｜ 当前版本：MNN 3.6.1（2026-07-22 发布）
> 适用读者：端侧模型部署工程师

---

## TL;DR（先看结论）

MNN 是一个**经过大规模生产验证**（阿里 30+ App、70+ 场景、日均数十亿次推理）的轻量级推理引擎，核心特点一句话概括：**转换工具链完整、CPU 汇编级优化极深、LLM/Diffusion 端侧运行时自成体系、不依赖厂商 NPU 即可在 2020 年后的大多数手机上跑大模型**。对端侧部署工程师而言，它是「CV 模型 + LLM 一体化部署」少数成熟的开源选择之一，尤其 CPU 后端性能在同类框架中领先（Decode 比 llama.cpp 快 20%~50%，Prefill 快 1 倍以上）。

| 维度 | 关键事实 |
|---|---|
| 开源协议 | Apache 2.0（商用友好） |
| 仓库 | [github.com/alibaba/MNN](https://github.com/alibaba/MNN)（3000+ commits，月度发版） |
| 体积 | Android 核心库约 800KB（armv7a）；iOS 静态库约 12MB，链接后增量约 2MB |
| 平台 | iOS 8.0+、Android 4.3+、Windows/Linux/macOS、嵌入式 POSIX、Web(WASM)、鸿蒙 |
| 模型格式 | ONNX / TensorFlow / Caffe / TorchScript / TFLite → 统一 `.mnn` 格式（FlatBuffer） |
| 计算后端 | CPU（ARM/x86/RISC-V）、GPU（OpenCL/Vulkan/Metal/CUDA）、NPU（QNN/CoreML/NNAPI/Hexagon/RKNN） |
| 大模型 | MNN-LLM：支持 Qwen3.5、Gemma4、Qwen3-VL、DeepSeek、Llama3、Baichuan、ChatGLM 等 |
| 量化 | FP16 / INT8 / INT4 / 2~3bit 权重量化、动态量化、KV Cache 量化（TQ3/TQ4）、HQQ/AWQ/GPTQ |
| 学术背书 | MLSys 2020（移动端推理优化）、OSDI 2022（Walle 端云协同系统） |

---

## 一、框架概览

### 1.1 定位与发展

MNN 由阿里巴巴（淘宝技术团队）开发，2019 年开源，最初目标是解决淘宝系 App 中数十个 AI 场景在移动端的**推理性能与包体积**矛盾。其设计哲学有三条主线：

1. **极致轻量**：零外部依赖，核心推理库（CPU+GPU）在 Android armv7a 上仅约 800KB；`MNN_BUILD_MINI` 编译选项可再减约 25%（限制为固定输入尺寸的模型）。
2. **跨平台通用**：一份代码支持 iOS/Android/Windows/Linux/macOS/嵌入式/Web，覆盖主流模型格式。
3. **生产级性能**：ARM/x86 大量手写汇编内核，接近硬件算力峰值；支持 Winograd 卷积、Strassen 矩阵乘、int4/int8/fp16/bf16 低精度内核。

2024 年起，MNN 的重心明显转向**端侧大模型**：推出 MNN-LLM 与 MNN-Diffusion（合称 MNN-Transformer），并发布了 Android/iOS 上的多模态 LLM App（文本、视觉、语音、文生图全离线）。

### 1.2 版本近况（2026 年）

| 时间 | 事件 |
|---|---|
| 2026-07-22 | **3.6.1 发布，新增 Hexagon 后端**（高通 Hexagon DSP 加速） |
| 2026-06 | 3.6.0：Gemma4 全模态、Qwen3.5、dflash 推测解码、**CPU/GPU 全栈 2/3-bit 权重量化**、KleidiAI 升级 v1.16.0、Wan2.1-T2V-1.3B 文生视频、SD 3.5 Medium |
| 2026-08 | RKNN（瑞芯微 NPU）初始支持合入主干 |
| 持续 | ARMv8.2/v8.6 decode 深度优化、Metal LLM prefill/decode 优化（M4/M5 实测）、CUDA Blackwell(sm_120) 支持 |

> 趋势判断：MNN 正在沿「更低比特量化（2/3-bit）+ 更多 NPU 后端 + 多模态模型」三条线快速演进，迭代活跃度在端侧推理框架中属第一梯队。

---

## 二、整体架构

### 2.1 分层架构总览

```
┌─────────────────────────────────────────────────────────────────┐
│                      应用层 / 语言绑定层                          │
│   Android App (JNI)   iOS App (Swift/OC)   PyMNN (Python)      │
│   MNN-LLM App / MNN-Diffusion App / MNNChat                    │
├─────────────────────────────────────────────────────────────────┤
│                    专用运行时（MNN-Transformer）                  │
│  ┌──────────────────────────┐  ┌──────────────────────────────┐ │
│  │ MNN-LLM 引擎              │  │ MNN-Diffusion 引擎            │ │
│  │ Llm::createLLM / Tokenizer│  │ Stable Diffusion / FLUX      │ │
│  │ KV Manager / Sampler      │  │ / SD3.5 / Wan2.1 文生视频     │ │
│  │ LoRA / Attention 插件     │  │ (VAE / UNet / DiT)           │ │
│  └──────────────────────────┘  └──────────────────────────────┘ │
├─────────────────────────────────────────────────────────────────┤
│                  前端运行时 API（动态图 / 静态图）                 │
│   Express API (VARP / Executor / Module)   │  Interpreter API   │
│   PyTorch 风格动态构图、控制流、训练            │  (静态图加载推理)  │
├─────────────────────────────────────────────────────────────────┤
│                    核心引擎层（source/core）                      │
│   Interpreter ──► Session ──► Pipeline ──► Backend/Execution    │
│   Tensor（NCHW/NC4HW4 布局）  GeometryComputer（图分解/几何变换）  │
│   Shape 推断   内存池管理   线程池（大小核绑定）                    │
├─────────────────────────────────────────────────────────────────┤
│                      异构计算后端层（source/backend）              │
│  CPU │ ARM NEON / FP16(ARMv8.2) / sdot·smmla / RVV / x86 AVX   │
│  GPU │ OpenCL │ Vulkan │ Metal │ CUDA(TensorCore)              │
│  NPU │ CoreML │ NNAPI │ QNN(高通) │ Hexagon(DSP) │ RKNN        │
├─────────────────────────────────────────────────────────────────┤
│                     离线工具链（tools/）                          │
│  MNN-Converter（格式转换+图优化）  MNN-Quant（量化/压缩）           │
│  llmexport.py（LLM导出）  auto_quant.py（自动压缩策略）            │
├─────────────────────────────────────────────────────────────────┤
│                     模型格式（schema/）                           │
│        FlatBuffer IR（MNN.fbs）──► .mnn 文件（跨平台/可加密）      │
└─────────────────────────────────────────────────────────────────┘
```

### 2.2 源码目录结构

```
MNN/
├── include/MNN/          # 对外 C++ API（Interpreter.hpp、Tensor.hpp 等）
├── source/
│   ├── core/             # 核心引擎：Interpreter / Session / Pipeline / Tensor
│   ├── backend/          # 硬件后端：cpu / arm82 / opencl / metal / vulkan / cuda / qnn / coreml ...
│   ├── geometry/         # GeometryComputer：将复杂算子分解为 primitive Command
│   ├── shape/            # 全算子的 Shape 推断
│   └── cv/               # MNN-CV：类 OpenCV 图像处理（ARMv7a 上 <100KB）
├── express/              # Express API：VARP/Executor 动态图前端
├── transformers/
│   ├── llm/              # MNN-LLM：export（llmexport.py）+ engine（C++ 运行时）
│   └── diffusion/        # MNN-Diffusion 运行时
├── tools/
│   ├── converter/        # MNN-Converter（多框架模型转换 + 图优化）
│   └── quantization/     # 离线量化工具
├── pymnn/                # PyMNN Python 绑定与 pip 包
├── schema/               # .mnn 格式的 FlatBuffer schema
├── apps/Android、iOS     # MNNChat / TaoAvatar / Sana-Edit 等演示 App
├── project/              # 各平台构建脚本（android/ios/harmony）
└── benchmark/            # 性能基准（含 OSDI'22 论文测试脚本）
```

### 2.3 核心抽象：五个关键类

MNN 运行时的执行模型由五个核心类构成，理解它们就理解了 MNN 的执行主干：

| 类/接口 | 职责 | 关键方法 |
|---|---|---|
| `Interpreter` | 模型加载器：读取 `.mnn`（FlatBuffer）、校验、创建 Session | `createFromFile()` `createSession()` `getSessionInput/Output()` `runSession()` `resizeTensor/resizeSession()` |
| `Session` | 一次推理会话：管理一组 Pipeline 与运行时资源 | 内部持有多条 Pipeline |
| `Pipeline` | 计算管线：形状推理 → 几何变换 → 算子降级为 Command 序列 → 内存规划 | 管理张量分配（`Backend::onAcquireBuffer`）与算子间数据依赖 |
| `Runtime` | 后端工厂：管理某类硬件的共享资源（GPU context、线程池、tuning 缓存） | 按类型创建 Backend 实例 |
| `Backend` / `Execution` | 具体算子执行体：内存分配 + 每个算子的硬件实现 | `onCreate()` 按 op 类型创建 Execution |

**设计要点**：

- **前后端严格解耦**：前端（Express/Interpreter）完全不感知硬件；新增一个后端只需实现 `Runtime`/`Backend`/`Execution` 接口，核心引擎零改动。
- **Session 与 Pipeline 分离**：一个模型可创建多个 Session（不同后端、不同输入尺寸）；一个 Session 内可含多条 Pipeline（异构调度时，子图分别跑在 CPU/GPU/NPU，Pipeline 间自动插入数据拷贝）。
- **GeometryComputer 层**：复杂算子（如复杂的 Reshape/Broadcast）在此被「几何分解」为一组 primitive Command，降低后端需要实现的算子数量——这是 MNN 后端能快速铺开的原因之一。
- **首次运行自动 tuning**：GPU 后端（OpenCL/Vulkan）首跑时对 kernel 做 auto-tuning 并缓存，二次运行直接命中最优配置。

---

## 三、推理工作流程

### 3.1 端侧部署全流程（通用 CV 模型）

```
PyTorch/TF 训练模型
        │  torch.onnx.export / tf 冻结图
        ▼
   ONNX / PB / TFLite 模型
        │  MNNConvert（图优化：算子融合、常量折叠、布局转换 NC4HW4）
        │  可选：--weightQuantBits 量化 / --fp16
        ▼
     model.mnn（FlatBuffer，跨平台单一文件）
        │  集成进 App（Android so / iOS framework / 嵌入式交叉编译）
        ▼
   端侧运行时：Interpreter → Session → Pipeline → Backend
        │
        ▼
   推理结果（Tensor → 业务后处理）
```

### 3.2 运行时执行流程详解

以 `runSession()` 为核心，内部执行链路如下：

1. **模型加载**：`Interpreter::createFromFile()` 通过 `FileLoader` 读取 FlatBuffer 模型，`OpCommonUtils::checkNet` 校验合法性（mmap 方式，不整体解析，加载大模型时内存友好）。
2. **创建 Session**：依据 `ScheduleConfig`（后端类型、线程数、精度模式）创建 Session。
3. **构建 Pipeline**：Session 初始化 Pipeline；Pipeline 执行 Shape 推断与 Geometry 变换，把算子图降级为 Command 序列；异构配置下按后端切分为多个子 Pipeline。
4. **内存规划**：Pipeline 通过 `_allocTensor` → `Backend::onAcquireBuffer()` 完成张量内存分配；**内存池复用机制**使生命周期不重叠的张量共享内存（典型模型内存占用可降约 40%），推理全程零 malloc/free。
5. **算子创建**：对每个 Command，由对应 `Backend::onCreate()` 创建 `Execution`（硬件算子实现）。
6. **执行**：`runSession()` 按拓扑序执行各 Execution；CPU 后端多线程并行，任务分发至线程池（支持大小核绑定）。
7. **动态 shape**：输入尺寸变化时调用 `resizeTensor()` + `resizeSession()`，触发 Pipeline 重规划。

### 3.3 异构计算调度

`ScheduleConfig` 中可指定多个后端，MNN 将**子图级**调度到不同硬件（如 Conv 子图 → GPU，Softmax/Shape 类算子 → CPU），Pipeline 之间自动处理数据搬运与格式转换。这一机制对 NPU 后端尤其重要——NPU 通常只覆盖部分算子，剩余算子自动回退 CPU。

---

## 四、工具链：模型转换与压缩

### 4.1 MNNConvert（模型转换）

支持 ONNX（opset 7–19）、TensorFlow、Caffe、TorchScript、TFLite 输入。转换时执行的图优化包括：算子融合（Conv+BN+ReLU → 单算子）、常量折叠、Shape 预推断、布局优化（转 NC4HW4）、子图切分。转换后可用 Netron 直接可视化 `.mnn` 拓扑。

算子覆盖数量（README 数据）：**TensorFlow 178 个、ONNX 158 个、TorchScript 163 个、Caffe 52 个**，覆盖常见 CNN/RNN/GAN/Transformer。

```bash
# 基础转换（ONNX → MNN）
./MNNConvert -f ONNX --modelFile model.onnx --MNNModel model.mnn

# pip 安装版（推荐实验用）
pip install MNN          # 提供 mnnconvert / mnnquant / mnn 三个 CLI
mnnconvert -f ONNX --modelFile model.onnx --MNNModel model.mnn

# 常用可选参数
#   --fp16                     权重 FP16 存储，体积减半
#   --weightQuantBits 4        权重量化 4bit（2~8 可选）
#   --weightQuantBlock 128     block-wise 量化块大小（默认 0 = channel-wise）
#   --hqq                      HQQ 量化算法（精度更好，转换更慢）
#   --saveExternalData         权重外置为 .mnn.weight 文件（降低加载内存峰值）
```

### 4.2 后训练压缩方案（PTQ）对比

MNN 官方将压缩工具链总结为四种方案，均**无需重训练**：

| 方案 | 是否需数据 | 压缩率 | 推理加速 | 适用场景 |
|---|---|---|---|---|
| **权值量化**（2–8bit） | ❌ | 75%~87% | 默认无；开启动态量化后有 | 首选方案：一键、无校准数据、不改变计算行为 |
| **FP16 压缩** | ❌ | 50% | 无 | 精度敏感、只需减体积 |
| **自动压缩调优**（auto_quant.py） | ✅ 测试集 | 75%~87% | 同权值量化 | 逐算子自动选择 bit 数，保障精度 |
| **离线量化**（quantized.out） | ✅ 少量校准图 | 75% | ✅ 全图 INT8 推理 | 追求速度+体积双收益（传统 CV 模型） |

关键细节（与量化工程实践直接相关，可关联 Wiki 中 [[模型量化]] / [[量化算法流派]] 笔记）：

- **权重量化 vs 离线量化**：前者只压存储（计算时仍反量化为浮点），后者全图 INT8 计算（需要校准数据统计激活分布）。
- **动态量化（LLM 场景核心）**：编译加 `-DMNN_LOW_MEMORY=ON` + 运行时 `memory: "low"`，对仅权重量化的模型在**推理时在线统计输入分布并量化激活**，直接执行 int8×int4/int8 计算。CPU 侧采用 Per-Batch 方案，精度几乎无损；在支持 sdot/smmla（ARM v8.2+）的设备上获得实际加速。GPU 侧则将反量化 fused 进卷积/矩阵乘 kernel，直接读取 int4/int8 权重。
- **LLM 量化算法**：`llmexport.py` 支持 `--hqq` / `--awq` / GPTQ 权重导入，默认 4bit + block 64；3.6.0 起 CPU/GPU 全栈支持 2/3-bit 权重量化（ARM low-bit 内核 + OpenCL/Metal/Vulkan 三 GPU 后端）。
- **KV Cache 量化**：`attention_mode` 配置项支持 K/V 的 int8、TQ3、TQ4 量化（TurboQuant 算法：WHT 旋转 + Lloyd-Max 码本），4B+ 模型推荐 `14`（FlashAttention + KV-TQ4），内存节省 >30%。

---

## 五、MNN-LLM 专题：端侧大模型运行时

对端侧 LLM 部署工程师，这是 MNN 当前最有竞争力的部分。

### 5.1 组成与插件化架构

MNN-LLM（`transformers/llm/`）由**离线工具 + 插件 + 引擎**三部分组成：

| 组件 | 功能 |
|---|---|
| 导出工具（llmexport.py） | HF/ModelScope 的 PyTorch 模型 → ONNX → MNN；同时导出 tokenizer、embedding、config |
| Attention 插件 | Transformer 的 Self/Cross-Attention 算子实现（融合 kernel，降低内存访问量、提高 GPU 并发） |
| KV Manager | KV Cache 的申请、扩容、量化、磁盘预加载、多 prompt 选择性复用（rollback） |
| LoRA 插件 | 基于权重共享，同一基座模型以极小内存（仅 LoRA 权重）+ <10% 性能损失加载多个 LoRA，支持多 LoRA 并发 |
| Tokenizer | SentencePiece / Tiktoken，文本 ↔ token ids |
| Embedding / Sampler | 向量查表；9 种采样器（greedy/temperature/topK/topP/minP/tfs/typical/penalty/mixed 混合管线） |
| Engine | 组装以上插件 + MNN 模型推理，对外暴露 `Llm::createLLM()` 等 API |

### 5.2 LLM 部署完整工作流

```
① 获取模型        ② 导出（PC 上）                ③ 编译引擎（目标平台）
HF/ModelScope  →  python llmexport.py        →  cmake -DMNN_BUILD_LLM=ON \
   原始模型          --path Qwen2-0.5B-Instruct      -DMNN_LOW_MEMORY=ON \
                    --export mnn --hqq             -DMNN_SUPPORT_TRANSFORMER_FUSE=ON
                        │                                │
                        ▼                                ▼
              产物目录（见下）                    libMNN.so + libllm + llm_demo/llm_bench
                        │                                │
                        └──────────► ④ config.json 配置 ◄──┘
                                       （后端/线程/精度/采样器/KV量化）
                                          │
                                          ▼
                        ⑤ llm_demo 交互推理 / C++/Java/Python API 集成
```

**导出产物目录**（也可直接从 ModelScope 下载官方预转换模型 `MNN/Qwen3-VL-4B-Instruct-MNN` 等，跳过②）：

```
model_dir/
├── llm.mnn            # MNN 模型（图结构+量化权重索引）
├── llm.mnn.weight     # 外置权重（int4 量化）
├── llm.mnn.json       # 模型 JSON（用于叠加 LoRA / GPTQ 权重）
├── tokenizer.mtok     # 分词器
├── embeddings_bf16.bin# embedding 权重（bf16，非 Tie-Embedding 模型）
├── llm_config.json    # 模型结构配置（hidden_size / prompt_template 等）
└── config.json        # 运行时配置（人工可改）
```

### 5.3 关键运行时优化（工程视角）

| 优化技术 | 原理与收益 |
|---|---|
| **动态量化** | 权重 int4 存储但无需离线标定激活；运行时在线量化激活执行低比特矩阵乘。7B 模型 FP32 需约 25GB → int4 约 3.5GB，1.8B 不到 1GB |
| **磁盘映射（mmap）** | `use_mmap: true` 将模型权重映射到磁盘，内存紧张时自动卸载/换入，规避与其他模块叠加导致的 OOM；对性能影响小（大模型与其他模块通常不同时执行） |
| **KV 量化** | K 方向与 int8 矩阵乘 scale 数组增长方向一致 → K 用 int8；V 不一致 → FP8；进阶 TQ3/TQ4（TurboQuant），长对话场景内存增量大幅下降 |
| **FlashAttention** | `attention_mode` 高 3bit 开关，配合 KV 量化使用 |
| **投机解码** | lookahead（ngram 外推，适合输入输出重合度高的代码/摘要场景）、dflash、Eagle（CUDA）；吞吐最高翻倍 |
| **多 LoRA 并存** | `--lora_split` 导出独立 lora.mnn，运行时 `create_lora()` 动态切换/并发，一套基座多任务多"人设" |
| **Prefill 分块** | `chunk` 配置限制单次处理 token 数，长 prompt 分块运行，控制峰值内存 |

### 5.4 config.json 核心配置速查

```json
{
    "llm_model": "llm.mnn",
    "llm_weight": "llm.mnn.weight",

    "backend_type": "cpu",          // cpu / opencl / metal / hexagon
    "thread_num": 4,                // opencl 时官方建议 68（tuning wide 模式）
    "precision": "low",             // low=尽量 fp16
    "memory": "low",                // low=开启动态量化
    "max_new_tokens": 512,
    "reuse_kv": true,               // 多轮对话复用 KV Cache
    "attention_mode": 14,           // FA + KV-TQ4（4B+模型推荐）；8=仅FA；10=FA+KV-INT8
    "use_mmap": true,               // 手机上建议开启
    "dynamic_option": 0,            // CPU feature map 量化粒度：0=per-channel,2=per-block

    "sampler_type": "mixed",
    "mixed_samplers": ["topK", "tfs", "typical", "topP", "min_p", "temperature"],
    "temperature": 0.8, "top_k": 40, "top_p": 0.9,
    "repetition_penalty": 1.05
}
```

---

## 六、核心优势总结

### 6.1 优势矩阵

| 优势 | 证据/数据 |
|---|---|
| **① 极致轻量** | Android 核心库 ~800KB；无外部依赖；`MNN_BUILD_MINI` 再减 25%；MNN-CV 图像处理库 ARMv7a 上 <100KB |
| **② CPU 性能领先** | 大量 ARM/x86 手写汇编；Winograd 应用于 3×3~7×7 对称卷积（业界首个用于转置卷积的实现）；ARM v8.2 FP16 计算速度×2，sdot/VNNI ×2.5 |
| **③ 不挑硬件的 LLM 方案** | 不依赖厂商 NPU，2020 年后手机基本都能跑 LLM 小模型；同时又有 QNN/Hexagon/CoreML/RKNN 等加速路径 |
| **④ 一体化工具链** | 转换、量化、压缩、benchmark、可视化（Netron 支持）、模型市场（ModelScope MNN 官方模型）全链路覆盖 |
| **⑤ 生产验证** | 阿里 30+ App、70+ 场景、日均数十亿次推理；OSDI'22/MLSys'20 论文背书，benchmark 脚本开源可复现 |
| **⑥ 全模态** | 一个引擎同时覆盖 LLM（文本/VL/Omni 语音）与 Diffusion（SD/FLUX/文生视频），后端优化自动惠及所有模型类型 |

### 6.2 实测性能数据（引用淘宝技术博客，小米 14）

**Qwen2-1.5B（int4），Prefill -- Decode（tok/s）**：

| 方案 | 64 tok 输入 | 256 tok 输入 | 1024 tok 输入 |
|---|---|---|---|
| **MNN-LLM CPU 4线程** | **225.19 -- 53.65** | **298.89 -- 52.45** | **236.76 -- 45.70** |
| MNN-LLM OpenCL | 153.42 -- 26.92 | 166.82 -- 26.33 | 237.31 -- 20.87 |
| llama.cpp CPU 4线程 | 46.22 -- 30.05 | 42.06 -- 26.39 | 37.37 -- 22.07 |
| llama.cpp OpenCL | 6.05 -- 4.44 | 16.08 -- 4.26 | 23.09 -- 3.30 |
| fastllm CPU 4线程 | 26.33 -- 9.29 | 25.91 -- 8.72 | 19.45 -- 6.47 |
| MLC-LLM OpenCL | 137.6 -- 25 | 146.3 -- 19.5 | 83.5 -- 11.9（易卡死） |

**结论**：CPU 后端 Decode 优势 20%~50%，**Prefill 快 1 倍以上**；GPU 小模型快 30%+，大模型与 MLC-LLM 持平但更稳定。其他参考：8Gen1 芯片上 1.8B 模型 Decode 35+ tok/s；SD1.5 生成 512×512 图片约 40s（2s/iter）；骁龙 888 上 ResNet-50 约 28ms/帧。

---

## 七、使用示例

### 7.1 示例一：CV 模型部署（C++，经典 Interpreter API）

**Step 1 转换+量化：**

```bash
pip install MNN
mnnconvert -f ONNX --modelFile mobilenetv2.onnx \
    --MNNModel mobilenetv2.mnn \
    --weightQuantBits 8 --fp16
```

**Step 2 C++ 推理：**

```cpp
#include <MNN/Interpreter.hpp>
#include <MNN/Tensor.hpp>

int main() {
    // 1. 创建解释器（mmap 加载 .mnn）
    std::unique_ptr<MNN::Interpreter> net(
        MNN::Interpreter::createFromFile("mobilenetv2.mnn"));

    // 2. 调度配置：后端 + 线程 + 精度
    MNN::ScheduleConfig config;
    config.type = MNN_FORWARD_CPU;        // 可选 MNN_FORWARD_OPENCL/METAL/...
    config.numThread = 4;
    MNN::BackendConfig backendConfig;
    backendConfig.precision = MNN::BackendConfig::Precision_Low; // 尽量 fp16
    config.backendConfig = &backendConfig;

    // 3. 创建会话
    MNN::Session* session = net->createSession(config);

    // 4. 填充输入（Host Tensor -> Device Tensor）
    auto inputTensor = net->getSessionInput(session, nullptr);
    float inputData[1 * 3 * 224 * 224];               // 预处理后的数据
    auto hostTensor = MNN::Tensor::create(inputTensor->shape(),
        halide_type_of<float>(), inputData, MNN::Tensor::CAFFE);
    inputTensor->copyFromHostTensor(hostTensor);

    // 5. 执行推理
    net->runSession(session);

    // 6. 读取输出
    auto outputTensor = net->getSessionOutput(session, nullptr);
    MNN::Tensor hostOutput(outputTensor, MNN::Tensor::CAFFE);
    outputTensor->copyToHostTensor(&hostOutput);
    float* logits = hostOutput.host<float>();         // 后处理 argmax 等
    return 0;
}
```

**动态 shape 场景**（输入尺寸变化时）：

```cpp
net->resizeTensor(inputTensor, {1, 3, 512, 512});
net->resizeSession(session);   // 触发 Pipeline 重规划
```

### 7.2 示例二：端侧 LLM 部署（全流程）

**Step 1 导出模型（PC）：**

```bash
cd MNN/transformers/llm/export
pip install -r requirements.txt

# 方式 A：自行导出（4bit + HQQ，推荐加 --hqq 提精度）
python llmexport.py \
    --path /path/to/Qwen2.5-1.5B-Instruct \
    --export mnn \
    --quant_bit 4 --quant_block 128 \
    --hqq

# 方式 B：直接下载官方预转换模型
pip install modelscope
modelscope download --model MNN/Qwen3-VL-4B-Instruct-MNN \
    --local_dir Qwen3-VL-4B-Instruct-MNN
```

**Step 2 编译引擎（Android 为例）：**

```bash
cd project/android && mkdir build_64
../build_64.sh "-DMNN_LOW_MEMORY=true \
    -DMNN_BUILD_LLM=true \
    -DMNN_SUPPORT_TRANSFORMER_FUSE=true \
    -DMNN_ARM82=true \
    -DMNN_OPENCL=true \
    -DMNN_USE_LOGCAT=true"
make install   # 产出 libMNN.so / llm_demo / llm_bench
```

**Step 3 推送到手机运行：**

```bash
adb push build_64/llm_demo /data/local/tmp/
adb push Qwen2.5-1.5B-Instruct-MNN /data/local/tmp/
adb shell 'cd /data/local/tmp && \
    export LD_LIBRARY_PATH=.:$LD_LIBRARY_PATH && \
    ./llm_demo Qwen2.5-1.5B-Instruct-MNN/config.json'
```

多模态输入语法（VL/Omni 模型）：

```
<img>https://xxx/demo.jpeg</img>介绍一下图片里的内容
<audio>https://xxx/translate.wav</audio>介绍一下音频里的内容
```

**Step 4（可选）性能基准：**

```bash
./llm_bench -m ./model/config.json -a cpu,opencl -t 4,68 \
    -p 64,256,1024 -n 128 -kv true -rep 5 --profile
# 注意：OpenCL 首跑会 tuning 较慢，需跑第二次取真实数据
```

### 7.3 示例三：LLM 的 C++ / Python API 集成

**C++（多轮对话 + 流式输出）：**

```cpp
#include "llm.hpp"

int main() {
    auto llm = std::shared_ptr<Llm>(Llm::createLLM("config.json"));
    llm->load();

    ChatMessages messages;   // vector<pair<role, content>>
    messages.emplace_back("system", "You are a helpful assistant.");
    messages.emplace_back("user", "你好");
    llm->response(messages, &std::cout);        // 流式打印

    messages.emplace_back("assistant", assistant_reply);
    messages.emplace_back("user", "介绍一下端侧部署");
    llm->response(messages, &std::cout);        // reuse_kv 自动复用上下文
}
```

**Python（PyMNN）：**

```python
import MNN.llm as llm

llm_model = llm.create("./model_dir/config.json")
llm_model.load()
out = llm_model.response("你好", True)   # True = 流式
print(out)
```

### 7.4 示例四：传统模型离线 INT8 量化（需校准图）

```bash
# 编译量化工具：cmake -DMNN_BUILD_QUANTOOLS=ON
./quantized.out --modelFile model.mnn \
    --outputFile model_int8.mnn \
    --inputImagesDir ./calib_images/
```

---

## 八、横向对比（端侧部署选型参考）

| 维度 | MNN | TensorFlow Lite | ncnn | llama.cpp | MLC-LLM |
|---|---|---|---|---|---|
| 定位 | 全模型类型端侧引擎 | 通用端侧（Google 系） | CV 端侧 | LLM 专用 | LLM 专用（TVM 系） |
| 核心库体积 | ~800KB | 数 MB（含 NNAPI delegate 更大） | ~500KB 级 | MB 级 | 编译产物较大 |
| CPU 性能 | **第一梯队**（汇编极深） | 中 | 第一梯队 | 中（LLM） | 中 |
| GPU 后端 | OpenCL/Vulkan/Metal/CUDA | GPU delegate（厂商绑定） | Vulkan | Vulkan（较弱） | 各平台 |
| NPU | QNN/Hexagon/CoreML/NNAPI/RKNN | NNAPI/CoreML 生态最全 | 有限 | 无 | 有限 |
| LLM 支持 | **原生一体化**（含 VL/Omni/Diffusion） | 有限（MediaPipe LLM Inference） | 无 | 最广（GGUF 生态） | 强 |
| 量化 | 2/3/4/8bit+FP16+KV量化+动态量化 | int8/int16/fp16+NNAPI 全整型 | int8/fp16/pack8 | Q4_K/Q8 等 K-quants 极丰富 | 4bit/q4f16 |
| 动态构图/训练 | Express API 支持端侧训练 | 有限 | 无 | 无 | 无 |
| 生态成熟度 | 国内生态好、模型市场 | 全球生态最大 | 腾讯系、CV 社区活跃 | 社区最活跃 | 学术前沿 |

**选型建议**：CV+LLM 混合业务、国产芯片适配、需要极致 CPU 性能 → MNN；纯 LLM 且追求社区/模型格式通用性 → llama.cpp；Google/Apple 官方 NPU 通路优先 → TFLite/CoreML；只做 CV 且团队已熟 ncnn → ncnn。

---

## 九、局限性与工程注意事项

1. **文档滞后于代码**：新特性（如 2/3-bit、RKNN）往往先合入主干，ReadTheDocs 文档更新滞后，生产排障需读源码。文档站部分旧链接已 404，建议以 GitHub 最新 README 与 release notes 为准。
2. **部分 NPU 覆盖有限**：Apple ANE 只能经 CoreML 间接使用；Hexagon 后端刚发布（仅支持 4-bit 对称量化 + Transformer C4 导出）；RKNN 为初始支持。深度 NPU 优化仍需评估。
3. **OpenCL 调优门槛**：首次运行 tuning 慢且强依赖设备；`thread_num=68` 这类"魔法值"（opencl tuning wide 模式）对新用户不直观。
4. **训练能力是二线**：MNN 支持端侧训练（Express API + MNN-Train），但主线明确是推理；QAT 生态不如 PTQ 成熟。
5. **自定义算子成本**：Converter 不支持的算子需要手写 Execution 注册，跨后端时需分别实现；转换前务必核对算子兼容性报告。
6. **动态 shape 文档不全**：支持动态输入，但复杂场景（多动态维度）行为需实测验证。
7. **LLM 模型覆盖节奏**：新模型（如 Gemma4/Qwen3.5）需要官方更新 llmexport 适配，冷门模型可能需自行适配导出脚本。

---

## 十、学习资源

| 资源 | 链接 |
|---|---|
| GitHub 仓库（README_CN 中文） | https://github.com/alibaba/MNN |
| 官方文档 | https://mnn-docs.readthedocs.io/ |
| LLM 部署文档 | https://mnn-docs.readthedocs.io/en/latest/transformers/llm.html |
| 模型压缩指南 | https://mnn-docs.readthedocs.io/en/latest/tools/compress.html |
| 阿里技术博客：MNN 在大模型端侧部署上的探索（性能对比数据来源） | https://blog.csdn.net/Taobaojishu/article/details/143949568 |
| OSDI'22 论文（Walle 端云协同系统，含 MNN 设计与 benchmark） | https://www.usenix.org/conference/osdi22/presentation/lv |
| MLSys'20 论文（移动端推理优化） | MNN: A Universal and Efficient Inference Engine |
| ModelScope MNN 官方预转换模型 | https://modelscope.cn/organization/MNN |
| 官方演示 App（MNNChat 等） | 仓库 `apps/` 目录 |

**建议阅读路径**（结合端侧 LLM 学习主线）：
1. 官方 LLM 文档过一遍部署流程 → 2. 精读 OSDI'22 论文的 MNN 章节（架构设计动机）→ 3. 源码：`source/core/Pipeline.cpp`（执行主干）+ `transformers/llm/engine`（LLM 运行时）→ 4. 动手：ModelScope 拉一个 Qwen3 0.6B-MNN 模型，在 Android 真机上跑通 llm_demo + llm_bench，对照 config.json 逐项实验（attention_mode/dynamic_option/mmap）→ 5. 延伸对比 llama.cpp 的量化格式（可衔接 [[量化算法流派]] 笔记）。

---

## 附录：编译选项速查（LLM 相关）

| CMake 宏 | 作用 |
|---|---|
| `MNN_BUILD_LLM` | 构建 MNN-LLM 运行时（libllm / llm_demo） |
| `MNN_LOW_MEMORY` | 低内存模式（动态量化等，端侧 LLM 必开） |
| `MNN_SUPPORT_TRANSFORMER_FUSE` | Transformer 算子融合（性能关键） |
| `MNN_ARM82` | ARM v8.2 FP16/sdot 加速（Android） |
| `MNN_OPENCL` / `MNN_METAL` / `MNN_VULKAN` | GPU 后端 |
| `MNN_AVX512` | x86 AVX512（PC 端） |
| `MNN_BUILD_LLM_OMNI` | Omni 语音多模态 |
| `MNN_QNN` + `MNN_WITH_PLUGIN` | 高通 QNN NPU |
| `MNN_BUILD_CONVERTER` / `MNN_BUILD_QUANTOOLS` | 转换/量化工具链 |
| `MNN_BUILD_MINI` | 裁剪 25% 体积（限固定输入尺寸模型） |

---

*报告基于 GitHub 仓库、MNN 官方文档、阿里技术博客及 OSDI'22 论文等公开资料整理，数据截至 2026 年 9 月（MNN 3.6.1）。性能数据引用自官方测试环境（小米 14 等），实际表现因设备/模型/配置而异，建议用 llm_bench 在目标设备实测。*
