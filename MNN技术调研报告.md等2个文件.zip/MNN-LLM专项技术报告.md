# MNN-LLM 端侧大模型推理引擎专项技术报告

> 调研对象：MNN-LLM — 基于 MNN 引擎的端侧大语言模型运行时（含 VL 视觉 / Omni 全模态）
> 调研时间：2026-09 ｜ 引擎版本：MNN 3.6.1 ｜ 论文：arXiv 2506.10443（阿里 MNN 团队）
> 适用读者：端侧大模型部署工程师
> 姊妹篇：《MNN 技术调研报告》（框架整体架构），本报告聚焦 LLM 运行时

---

## TL;DR

MNN-LLM 是一个**面向手机的 LLM 专用推理引擎**，围绕移动端两大瓶颈——**内存墙（Memory Wall）与算力瓶颈**——做了一整套系统性优化。核心技术栈一句话：**DRAM-Flash 混合存储 + 组合量化（int4/int8 权重 + 运行时激活量化 + KV Cache 分通道量化）+ 硬件驱动数据重排 + 多核负载均衡**。论文数据（骁龙 8 Gen 3）：CPU Prefill 比 llama.cpp 快 **8.6×**，Decode 快 **2.3×**；GPU Prefill 领先达 **25.3×**。不依赖厂商 NPU，2020 年后主流手机即可运行 1.5B~8B 量化模型。

| 维度 | 关键事实 |
|---|---|
| 代码位置 | `transformers/llm/`（export 导出工具 + engine 运行时） |
| 支持平台 | Android / iOS / macOS / Linux / Windows / Web(WASM) / 鸿蒙 |
| 运行后端 | CPU（含 ARM SME2/sdot/i8mm、x86 AVX512、RISC-V RVV）、OpenCL、Metal、Vulkan、CUDA、Hexagon(DSP)、QNN(NPU) |
| 模型家族 | Qwen 全系（含 Qwen3.5/VL/Omni）、Gemma4（全模态）、Llama3、DeepSeek-R1、Baichuan、Yi、InternLM、Phi、MiniCPM、ReaderLM、SmolLM、TinyLlama、MobileLLM 等 |
| 量化能力 | 权重 2/3/4/8bit（HQQ/AWQ/GPTQ）、激活动态 int8、KV Cache int8/FP8/TQ3/TQ4 |
| 性能参考 | 8Gen3 + Qwen2-1.5B int4：CPU Prefill 236 tok/s / Decode 45 tok/s（1024 输入） |
| 生产形态 | MNN Chat App（Android/iOS，模型市场一键下载）、llm_demo CLI、C++/Java/Python API |
| 一手资料 | [论文 PDF](https://www.arxiv.org/pdf/2506.10443) ｜ [官方文档](https://mnn-docs.readthedocs.io/en/latest/transformers/llm.html) ｜ [代码](https://github.com/alibaba/MNN/tree/master/transformers) |

---

## 一、定位与总体认知

### 1.1 MNN-LLM 是什么

MNN-LLM 是构建在 MNN 通用推理引擎之上的 **LLM 专用运行时解决方案**（与 MNN-Diffusion 合称 MNN-Transformer）。它的使命是：**让 LLM 在任何人的设备上本地运行**（手机 / PC / IoT），不联网、不上传数据。

与"通用引擎 + LLM 模型"的简单组合不同，MNN-LLM 针对Transformer 推理的特殊性（自回归逐 token 生成、KV Cache 持续增长、Decode 阶段访存受限）做了**全链路定制**：从模型导出（llmexport）、量化策略、到运行时算子与内存管理。

### 1.2 与 MNN 主框架的关系

```
┌────────────────────────────────────────────────┐
│                MNN-LLM（本报告）                 │
│   导出工具        插件层              引擎层      │
│  llmexport.py   Tokenizer/KVMgr/    Llm 会话    │
│  (PC 离线)      LoRA/Sampler/       Prefill/    │
│                 Attention/Embedding  Decode     │
├───────────────────┬────────────────────────────┤
│      复用 MNN 通用能力：算子库 / 图优化 /        │
│      GeometryComputer / 异构后端 / 内存池        │
├────────────────────────────────────────────────┤
│     硬件：CPU / OpenCL / Metal / Vulkan /       │
│     CUDA / Hexagon / QNN                        │
└────────────────────────────────────────────────┘
```

**关键设计红利**：底层任何一次后端优化（如新 ARM 汇编内核、OpenCL tuning 改进）自动惠及 LLM 工作负载；反过来，LLM 场景催生的 Attention 融合、低比特 GEMV 等 kernel 也沉淀回通用引擎。

### 1.3 两大性能瓶颈的定性判断（理解全部优化的钥匙）

MNN-LLM 论文的核心洞察是 LLM 推理两阶段的本质差异：

| 阶段 | 计算特征 | 瓶颈类型 | 优化方向 |
|---|---|---|---|
| **Prefill（预填充）** | 一次并行处理整个 prompt，大矩阵乘 | **计算受限（Compute-bound）** | 指令集利用率、数据重排、多核均衡 |
| **Decode（解码）** | 逐 token 生成，每步需读取全部权重但计算量小 | **访存受限（Memory-bound）** | 减少每步搬运的字节数：量化、权重布局、混合存储 |

> Prefill 决定**首字响应时间（TTFT）**，Decode 决定**总生成时长**。MNN-LLM 在两阶段采用不同策略：Prefill 期间将 int4/int8 权重反量化为浮点走高吞吐浮点 kernel；Decode 期间直接执行低比特计算（CPU W4A8/W8A8），字节搬运量即速度。

---

## 二、系统架构

### 2.1 三大组成部分

MNN-LLM 由**离线工具 + 插件 + 引擎**三部分组成：

```
PC / 服务器（离线）                     手机 / 端侧（在线）
┌──────────────────────┐          ┌─────────────────────────────┐
│  ① 导出工具           │          │  ③ 插件与引擎                 │
│  llmexport.py         │  资源包   │  ┌───────────────────────┐  │
│  - torch→onnx→mnn    │ ───────► │  │ Engine（Llm 会话管理）  │  │
│  - tokenizer 导出     │          │  │ Prefill / Decode 调度   │  │
│  - embedding 导出     │          │  └──────────┬────────────┘  │
│  - 量化(2-8bit)       │          │  ┌──────────▼────────────┐  │
│  - LoRA 合并/分离     │          │  │ 插件层                 │  │
│  ② 量化工具           │          │  │ Tokenizer │ Embedding  │  │
│  MNNConvert           │          │  │ KV Manager│ Sampler    │  │
│  --weightQuantBits    │          │  │ LoRA │ Attention 融合   │  │
└──────────────────────┘          │  └──────────┬────────────┘  │
                                  │  ┌──────────▼────────────┐  │
                                  │  │ MNN 引擎（通用推理）    │  │
                                  │  │ CPU/GPU/DSP/NPU 后端   │  │
                                  │  └───────────────────────┘  │
                                  └─────────────────────────────┘
```

### 2.2 插件层职责详解

| 插件 | 职责 | 技术要点 |
|---|---|---|
| **Engine** | 会话生命周期、Prefill/Decode 调度 | `Llm::createLLM()` 对外入口；管理上下文与生成循环 |
| **Tokenizer** | 文本 ↔ token ids | SentencePiece / Tiktoken 双实现，产出 `tokenizer.mtok` |
| **Embedding** | token id → 向量查表 | 权重独立存为 `embeddings_bf16.bin`（放 Flash，见 §4.1）；Tie-Embedding 模型复用主权重 |
| **Attention** | Self/Cross-Attention 算子 | 融合 kernel：QK^T、Softmax、PV 融合执行，降低中间结果访存；支持 FlashAttention 切换 |
| **KV Manager** | KV Cache 全生命周期 | 申请、扩容、量化（int8/FP8/TQ3/TQ4）、磁盘换入换出（mmap）、多 Prompt 选择性复用（rollback）、prefix 磁盘缓存 |
| **LoRA** | 多任务权重叠加 | 基于权重共享：基座常驻内存，`create_lora()` 动态挂载多个 LoRA 并支持并发；计算顺序优化（见 §4.6） |
| **Sampler** | logits → token | 9 种采样器 + mixed 混合管线（greedy/temperature/topK/topP/minP/tfs/typical/penalty/mixed） |

### 2.3 源码目录

```
transformers/llm/
├── export/                 # ① 导出工具
│   ├── llmexport.py        #    主入口（torch → onnx → mnn）
│   ├── requirements.txt
│   └── utils/lora.py       #    LoRA 处理
└── engine/                 # ③ 运行时
    ├── cpp/                #    核心（Llm 类、KV Manager、Sampler、Tokenizer）
    ├── android/            #    Android JNI（llm_mnn_jni.cpp）
    ├── ios/                #    iOS 集成
    └── demo/               #    llm_demo / llm_bench / rollback_demo
```

---

## 三、推理流程深度解析

### 3.1 端到端生成流程

```
用户输入 "介绍一下端侧部署"
   │
   ▼
① Tokenizer 编码 ──────────► [token ids]
   │
   ▼
② Embedding 查表（bf16，Flash 按需读取）
   │
   ▼
③ Prefill：整段 prompt 一次性并行前向
   │  - int4/int8 权重反量化为浮点，走高吞吐浮点 kernel
   │  - FlashAttention（可配）计算注意力
   │  - 逐层生成并存储 K/V → KV Cache（可量化）
   │  - 产出第一个 token（决定 TTFT）
   ▼
④ Decode 循环（自回归，每次 1 token）
   │  - 仅当前 token 走 Embedding → 前向
   │  - Attention 读取 KV Cache（增长方向访存）
   │  - 低比特直接计算（CPU: W4A8/W8A8）
   │  - logits → Sampler 采样 → 新 token
   │  - 新 K/V 追加进 KV Cache
   │  - 循环直至 EOS / max_new_tokens
   ▼
⑤ Tokenizer 解码 ──────────► 流式文本输出
```

### 3.2 会话生命周期（C++ 视角）

```cpp
auto llm = std::shared_ptr<Llm>(Llm::createLLM("config.json"));
//  ├─ 解析 config.json（后端/线程/精度/采样器）
//  ├─ mmap 加载 llm.mnn + llm.mnn.weight（不整体解析，内存友好）
//  ├─ 初始化 Tokenizer / Embedding / KV Manager / Sampler
llm->load();
llm->response("你好", &std::cout);
//  └─ 内部：tokenize → prefill → decode loop → 流式回调
//     多轮对话时 reuse_kv=true 跳过历史 token 的重新 prefill
```

### 3.3 关键运行时行为

| 行为 | 机制 | 工程意义 |
|---|---|---|
| 多轮对话 | `reuse_kv: true` 复用历史 KV Cache | 第二轮起只 prefill 新增 token，响应大幅加快 |
| 长上下文分块 | `chunk: 128` 限制单次处理 token 数 | 超长 prompt 分块 prefill，控制峰值内存 |
| KV 磁盘缓存 | `rollback_demo` + prefix cache 文件 | 系统提示词等公共前缀的 KV 首次落盘，二次启动跳过 prefill |
| 内存不足 | `use_mmap` / `kvcache_mmap` | 权重与 KV 映射到磁盘，与其他 App 模块内存叠加时自动换出，规避 OOM |
| 多 LoRA | `create_lora(name)` | 一套基座 + N 个轻量"人设/任务"头，并发会话各自挂载 |

---

## 四、核心优化技术（论文级拆解）

以下六项技术出自 MNN-LLM 论文（arXiv 2506.10443），是性能数字背后的支撑，也是理解代码的地图。

### 4.1 DRAM-Flash 混合存储（解决内存墙）

**原理**：按参数的访问模式分配存储介质。

| 参数类型 | 占比（Qwen2-7B） | 访问特征 | 存储策略 |
|---|---|---|---|
| Embedding 权重 | ≈15% | Decode 每步仅需当前 token 对应的**一行** | **存 Flash**，按需读取；bf16 保精度 |
| Layer / Lm head 权重 | ≈85% | 每步需完整读取 | 存 DRAM，int4/int8 量化 |
| KV Cache | 随上下文增长 | 逐层顺序访问 | DRAM 为主，**超阈值部分转 Flash** |

**KV Cache 的 Flash 延迟隐藏**：利用**预取（prefetching）**——在当前层的 MLP 计算和下一层的 QKV 投影期间，提前把下一层所需的 KV 从 Flash 读入 DRAM。只要缓存长度不超过约 3072 token，Flash 读取时间可被计算完全覆盖。

**收益**：Qwen2-7B bf16 Embedding 可省约 **2.18GB DRAM**，Decode 速度损失仅约 **0.014%**（一万分之1.4）——这是"内存墙换存储"的极致性价比。

### 4.2 组合量化（Combined Quantization）

不同部件按**精度敏感度 × 访问模式**选择不同量化格式：

| 部件 | 量化格式 | 理由 |
|---|---|---|
| Embedding | **bf16**（不量化） | Flash 存储，带宽压力小；精度敏感 |
| Layer 权重 | **int4 / int8 非对称** | Decode 每步全量读取，低比特直接决定速度 |
| Lm head 权重 | **优先 int8** | 输出分布敏感，精度损失放大到生成质量 |
| 激活值 | **运行时动态 int8** | 无需离线校准；CPU 走 W4A8/W8A8，GPU 走 W4A16/W8A16 |
| KV Cache - Key | **int4 / int8** | 与 Q 相乘的约简维度是 head_dim（**固定**），新增 K 可独立量化 |
| KV Cache - Value | **FP8** | 与 attention score 相乘的约简维度是 seq_len（**变化**）；FP8 允许新 V 独立量化，无需回改历史 V 的量化参数 |

**动态量化的巧妙之处**：传统低比特推理需离线统计各层 scale（GPTQ/KL 散度标定，对 LLM 成本极高）。MNN-LLM 直接运行"仅权重量化"的模型，**推理时在线统计当前输入的分布并计算 scale/bias**，CPU 侧采用 Per-Batch 方案——精度几乎无损，零校准成本。这是它能"一键导出即可跑"的根本原因。

**进阶（3.6.x 版本）**：K/V 的 TQ3/TQ4 量化（TurboQuant：WHT 旋转 + Lloyd-Max 码本），4B+ 模型内存再省 >30%。

### 4.3 硬件驱动数据重排（Hardware-Driven Data Reorder）

**Prefill/Decode 都归结为矩阵乘**，MNN-LLM 按目标 CPU 的**寄存器数量 R 与指令宽度**求解最优 Loop Tiling，最小化内存访问次数：

- 优化目标：min (e/eₚ)·(h/hₚ)·(l·eₚ + l·hₚ + hₚ·eₚ)，约束 eₚ+hₚ+hₚ·eₚ ≤ R（寄存器总量），lₚ = 指令宽度
- 按指令集定制：ARM **sdot** / **i8mm**（lₚ=8）/ AVX2 / AVX512 各有专属布局
- **K/V 直接以重排后的布局持久存储**，避免每次计算重复排列
- GPU 侧：权重重排为 Image 对象存储 `[l/lₚ, h, lₚ]`（lₚ=32），每个 work item 单次加载 128 bits，配合 GPU 的合并访存与向量化加载

### 4.4 多核负载均衡（big.LITTLE 适配）

手机 CPU 异构（超大核+大核+小核）。MNN-LLM 沿 `seqlen` 和 `h/hₚ` 维度并行切分计算，**按各核心实测算力分配 workload**（启动时探测），避免小核成为短板。4 线程扩展比 >3.5。

新版本进一步利用 **SME2**（可伸缩矩阵扩展，如骁龙 8 Elite）：编译开 `-DMNN_SME2=ON` 且硬件支持时自动走 SME2 加速路径，配合 `cpu_sme2_neon_division_ratio` 配置 SME 核与 NEON 核的 Prefill/Decode 工作量比。

### 4.5 混合精度与 Geometry Compute

- **混合浮点精度**：Softmax 用 **float32**（数值敏感）；Q·Kᵀ 用 **float16** 并对 Q 预乘 1/√dₖ 缩放防溢出（ARMv8.2+ FP16 计算速度 ×2）
- **Geometry Compute**：把 Transpose/Gather/Concat/Reshape 等 long-tail 算子抽象为**地址线性映射** f(x⃗)=offset⃗+stride⃗·x⃗，通过 Region Fusion 合并兼容映射、消除物理数据搬运，长尾开销减少约 3%——这也是 MNN 通用引擎的核心抽象之一

### 4.6 LoRA 计算顺序优化

在线加载 LoRA 时，利用矩阵乘结合律改写：

```
原始：  A' = W·A + (LoRA_A·LoRA_B)·A     ← 先算 r×h 大矩阵乘，开销大
优化：  A' = W·A + LoRA_A·(LoRA_B·A)     ← 先算 r×e 小矩阵乘，计算量随 rank r 陡降
```

配合权重共享（基座常驻、LoRA 独立加载），实现**一份基座内存 + 多 LoRA 并存并发**，性能损失 <10%。

### 4.7 投机解码（Speculative Decoding）

| 方案 | 原理 | 适用场景 |
|---|---|---|
| **lookahead** | ngram 历史外推生成草稿 + 主模型并行验证 | 输入输出重合度高：代码补全、文档摘要、RAG 引用 |
| **dflash** | 3.6.0 新增推测解码方案 | 通用加速 |
| **Eagle** | 草稿头模型（CUDA 后端已优化） | 服务端/高性能设备 |

---

## 五、模型支持与量化体系

### 5.1 支持的模型家族

| 类别 | 模型 |
|---|---|
| 文本 LLM | Qwen 全系（Qwen2/2.5/3/3.5）、Gemma（2/3/4）、Llama（2/3，含 TinyLlama、MobileLLM）、DeepSeek-R1（含 distilled）、Baichuan、Yi、InternLM、Phi、MiniCPM、SmolLM、ReaderLM（网页理解）、LFM、Hymt2 |
| 视觉 VL | Qwen2-VL / Qwen3-VL / Qwen2.5-VL、Gemma4 视觉版、Moondream |
| 全模态 Omni | Qwen2.5-Omni（Thinker-Talker 架构：文本+图像+语音输入，语音输出）、Gemma4 音频版 |
| 结构变体 | Gated Attention（Qwen3.5）、LinearAttention（GatedDeltaNet，含 L=1 decode 快速路径）、dual-RoPE（Gemma3） |

> 注意力结构上已覆盖 Full Attention、GQA、Linear Attention；新模型由官方持续适配 llmexport 导出脚本，冷门模型需自行适配。

### 5.2 模型获取三条路径

```bash
# 路径 A：官方预转换模型（推荐，最快上手）
modelscope download --model MNN/Qwen3-VL-4B-Instruct-MNN --local_dir ./model
# 也可在 HuggingFace taobao-mnn 组织（24+ 模型集合）或 MNN Chat App 内模型市场直接下载

# 路径 B：自行导出（可控量化参数）
python llmexport.py --path /path/to/Qwen2.5-1.5B-Instruct \
    --export mnn --quant_bit 4 --quant_block 128 --hqq

# 路径 C：导出 ONNX 后手动 MNNConvert（支持 5/6bit 等非默认比特）
python llmexport.py --path MODEL --export onnx
./MNNConvert --modelFile onnx/llm.onnx --MNNModel llm.mnn --keepInputFormat \
    --weightQuantBits=4 --weightQuantBlock=128 -f ONNX --transformerFuse=1 \
    --allowCustomOp --saveExternalData
```

**llmexport.py 参数速查**：

| 参数 | 说明 |
|---|---|
| `--path` | HF/ModelScope 模型目录（须 git lfs 完整下载） |
| `--export` | `mnn` / `onnx` |
| `--quant_bit` | 量化位数 4/8（默认 4） |
| `--quant_block` | block-wise 块大小（默认 64；128 精度更好体积略增） |
| `--lm_quant_bit` | lm_head 单独量化位数（精度敏感，可设 8） |
| `--hqq` / `--awq` | HQQ / AWQ 量化算法（提精度，推荐 --hqq） |
| `--lora_path` / `--lora_split` | 合并 LoRA / 分离导出独立 lora.mnn |
| `--test "query"` | 导出后即时对话验证 |

### 5.3 导出产物说明

```
model_dir/
├── llm.mnn             # 图结构 + 量化权重（核心模型）
├── llm.mnn.weight      # 外置权重文件（降低加载内存峰值）
├── llm.mnn.json        # 模型 JSON 描述（叠加 LoRA/GPTQ 权重用）
├── tokenizer.mtok      # 分词器
├── embeddings_bf16.bin # Embedding 权重（bf16；Tie-Embedding 模型无此文件）
├── llm_config.json     # 结构配置：hidden_size / layer_nums /
│                       # key_value_shape / prompt_template 等
└── config.json         # 运行时配置（人工可改，见 §7.2）
```

---

## 六、部署实战

### 6.1 引擎编译（按平台）

```bash
# ── 基础编译宏（LLM 必开三件套）────────────────
# -DMNN_BUILD_LLM=ON                构建 LLM 运行时
# -DMNN_LOW_MEMORY=ON               低内存模式（动态量化）
# -DMNN_SUPPORT_TRANSFORMER_FUSE=ON Transformer 算子融合（性能关键）

# ── macOS / Linux / Windows ──────────────────
mkdir build && cd build
cmake ../ -DMNN_BUILD_LLM=ON -DMNN_LOW_MEMORY=ON \
         -DMNN_SUPPORT_TRANSFORMER_FUSE=ON
make -j16
# x86 追加 -DMNN_AVX512=ON

# ── Android（含 OpenCL GPU + 全模态）──────────
cd project/android && mkdir build_64
../build_64.sh "-DMNN_LOW_MEMORY=true \
    -DMNN_BUILD_LLM=true \
    -DMNN_SUPPORT_TRANSFORMER_FUSE=true \
    -DMNN_ARM82=true \
    -DMNN_OPENCL=true \
    -DMNN_USE_LOGCAT=true \
    -DLLM_SUPPORT_VISION=true \
    -DMNN_BUILD_OPENCV=true -DMNN_IMGCODECS=true \
    -DLLM_SUPPORT_AUDIO=true -DMNN_BUILD_AUDIO=true \
    -DMNN_BUILD_DIFFUSION=ON \
    -DMNN_SEP_BUILD=ON"
make install    # 产物：build_64/lib/ 下的 libMNN.so + llm_demo + llm_bench

# ── iOS / macOS(GPU) ────────────────────────
sh package_scripts/ios/buildiOS.sh "-DMNN_ARM82=true -DMNN_LOW_MEMORY=true \
    -DMNN_SUPPORT_TRANSFORMER_FUSE=true -DMNN_BUILD_LLM=true -DMNN_METAL=ON"

# ── Web (WASM) ──────────────────────────────
emcmake cmake .. -DCMAKE_BUILD_TYPE=Release \
    -DMNN_FORBID_MULTI_THREAD=ON -DMNN_USE_THREAD_POOL=OFF \
    -DMNN_LOW_MEMORY=true -DMNN_BUILD_LLM=true \
    -DMNN_SUPPORT_TRANSFORMER_FUSE=ON
```

硬件特性宏：`MNN_ARM82`（v8.2 FP16/sdot）、`MNN_SME2`（SME2 矩阵扩展）、`MNN_AVX512`、`MNN_QNN`+`MNN_WITH_PLUGIN`（高通 NPU）、`MNN_BUILD_LLM_OMNI`（Omni 语音）。

### 6.2 运行时 config.json 完整参考

```json
{
    "llm_model": "llm.mnn",
    "llm_weight": "llm.mnn.weight",

    "backend_type": "cpu",
    "thread_num": 4,
    "precision": "low",
    "memory": "low",
    "max_new_tokens": 512,
    "reuse_kv": true,
    "use_mmap": true,

    "attention_mode": 8,
    "dynamic_option": 0,
    "chunk": 128,

    "sampler_type": "mixed",
    "mixed_samplers": ["topK", "tfs", "typical", "topP", "min_p", "temperature"],
    "temperature": 0.8,
    "top_k": 40, "top_p": 0.9, "min_p": 0.05,
    "repetition_penalty": 1.05
}
```

**重点配置项详解**：

| 配置 | 取值与语义 |
|---|---|
| `backend_type` | `cpu` / `opencl` / `metal` / `hexagon`；OpenCL 时 `thread_num` 官方建议 **68**（代表 buffer 存储 + tuning wide 模式，非线程数） |
| `precision` | `low` = 尽量 fp16（推荐） |
| `memory` | `low` = 开启动态量化（低内存模式核心开关） |
| `attention_mode` | 编码 `FA×8 + KV量化模式`。**8**=FlashAttention 不量化（默认）；**10**=FA+KV-int8（精度几乎无损）；**14**=FA+KV-TQ4（4B+ 推荐，省内存>30%）；**12**=FA+KV-TQ3（极致压缩）。注意：TQ3/TQ4 为 CPU 专属，Metal 仅支持 0/1/2 模式，OpenCL/Vulkan/CUDA 不支持 FA 切换 |
| `dynamic_option` | CPU 激活量化粒度：0=per-channel / 1=per-tensor / 2=per-block；**8+n 变体加速 Decode 但短 prompt（<300）Prefill 显著变慢** |
| `use_mmap` | 权重映射磁盘，手机上建议 `true` |
| `kvcache_mmap` / `chunk` | KV Cache 落盘 / Prefill 分块，长上下文内存吃紧时启用 |
| `cpu_sme2_neon_division_ratio` | SME2 设备多核策略：`8x+y`（x=Prefill 阶段 SME:NEON 工作量比，y=Decode 比），默认 41，常见 41/49/33 |

**投机解码（lookahead）配置**：`speculative_type`、`draft_predict_length`（2-8）、`draft_match_strictness`、`lookup_file` 等，适合输入输出重合度高的场景。

### 6.3 CLI 工具

```bash
# llm_demo：交互聊天 / 按行回复
./llm_demo model_dir/config.json
./llm_demo model_dir/config.json prompt.txt

# 多模态输入语法
<img>https://xxx/demo.jpeg</img>介绍一下图片里的内容
<audio>https://xxx/audio.wav</audio>介绍一下音频里的内容

# llm_bench：性能基准
./llm_bench -m ./model/config.json -a cpu,opencl -t 4,68 \
    -p 64,256,1024 -n 128 -kv true -rep 5 --profile
# -p=prompt长度(测TTFT)  -n=生成长度  -kv=true(考虑历史KV,与llm_demo一致)
# --profile=算子级耗时统计  -fp=结果写markdown文件
# ⚠ OpenCL 首跑 tuning 慢且缓存，需第二次运行取真实数据

# rollback_demo：多 Prompt KV Cache 选择性复用
./rollback_demo config.json prompt.txt <cache_prefix_in_disk> <max_token_number>
# cache_prefix_in_disk=1：公共前缀 KV 落盘，二次启动跳过 Prefill
```

**Hexagon(DSP) 后端运行**（3.6.1+）：

```bash
adb push qwen3_0_6b_hexagon /data/local/tmp/MNN/
adb push libMNN.so libMNN_htpops.so libMNN_htpops_skel.so llm_demo /data/local/tmp/MNN/
adb shell 'cd /data/local/tmp/MNN && \
    export LD_LIBRARY_PATH=.:$LD_LIBRARY_PATH && \
    export ADSP_LIBRARY_PATH=/data/local/tmp/MNN && \
    ./llm_demo qwen3_0_6b_hexagon/config.json prompt.txt'
# ⚠ Hexagon 仅支持 4-bit 对称量化（导出 --quant_bit 4 --sym）+ Transformer C4 导出
```

---

## 七、API 集成（三种语言）

### 7.1 C++（`llm.hpp`）

```cpp
#include "llm.hpp"

int main() {
    // 创建与加载
    auto llm = std::shared_ptr<Llm>(Llm::createLLM("config.json"));
    llm->load();

    // 单轮流式
    llm->response("你好", &std::cout);

    // 多轮对话（ChatMessage = pair<role, content>）
    ChatMessages messages;
    messages.emplace_back("system", "You are a helpful assistant.");
    messages.emplace_back("user", "介绍一下端侧部署");
    llm->response(messages, &std::cout);

    // Function Calling：first="json" 传完整 JSON，自动套 chat template
    messages.emplace_back("json", R"({"role":"assistant","tool_calls":[...]})");
    messages.emplace_back("tool", R"({"temperature": 72})");
}
```

**多 LoRA 并发**：

```cpp
llm->load();
auto chat = [&](const std::string& lora_name) {
    auto* current = llm->create_lora(lora_name);   // 挂载指定 LoRA
    current->response("Hello");
};
std::thread t1(chat, "lora_1.mnn"), t2(chat, "lora_2.mnn");
t1.join(); t2.join();   // 两个"人设"并发对话，共享基座内存
```

**Omni 语音输出**：

```cpp
llm->setWavformCallback([&](const float* ptr, size_t size, bool last) {
    audio_player.play(ptr, size, last);   // 流式播放 24kHz Float PCM
    return true;
});
llm->response("你好");
llm->generateWavform();   // 文本生成结束后开始输出语音
```

### 7.2 Android（Java/Kotlin）

经典 JNI 封装为极简的 `Chat` 类：

```java
// com.mnn.llm.Chat（JNI 桥接 llm_mnn_jni.cpp → mls::LlmSession）
public class Chat {
    static { System.loadLibrary("llm"); }
    public native boolean Init(String modelDir);   // 加载模型目录
    public native String Submit(String input);     // 提交 prompt（异步生成）
    public native byte[] Response();               // 轮询获取增量输出
    public native void Done();                     // 清空响应缓冲
    public native void Reset();                    // 重置会话状态
}
```

新版 MNN Chat App（`apps/Android/MnnLlmChat`）为 Kotlin + MVVM 架构：

- **UI 层**：`MainActivity`（模型市场 ModelMarketFragment / 本地模型 ModelListFragment / 历史 ChatHistoryFragment）+ `ChatActivity`（对话界面）
- **控制层**：`ChatPresenter.createSession()` 按模型类型分流——LLM 走 `LlmRuntimeController.ensureSession()`（会话复用防重复加载），Diffusion 走 `ChatService`
- **模型市场**：`model_market.json` 定义远端目录（vendor/size_gb/下载源），`ModelDownloadManager` 支持 HuggingFace/ModelScope 下载 + **前台服务**保障 GB 级模型后台下载
- **Native 层**：`llm_mnn_jni.cpp` 创建 `mls::LlmSession`，`submitNative` 经 progressListener 流式回传 token
- 编译 App：`./gradlew assembleStandardDebug`（自动从 `project/android/build_64/lib/` 引用并打包 libMNN.so）

### 7.3 Python（PyMNN）

```python
import MNN.llm as llm

model = llm.create("./model_dir/config.json")
model.load()
out = model.response("你好", True)   # True = 流式
print(out)

# 也可直接 token 级调用
out_ids = model.generate([151644, 872, 198, 108386, 151645, 198])
```

---

## 八、性能基准

### 8.1 论文官方对比（骁龙 8 Gen 3 / 小米 14，Qwen2 与 Llama3 int4 非对称量化）

| 对比项 | vs llama.cpp | vs fastllm | vs MLC-LLM |
|---|---|---|---|
| CPU Prefill | **最高 8.6×** | **最高 20.5×** | — |
| CPU Decode | **2.3×** | **8.9×** | — |
| GPU Prefill (OpenCL) | **最高 25.3×** | — | 2.8× |
| GPU Decode (OpenCL) | 7.1× | — | 1.7× |

**Qwen2-1.5B 详细数据（CPU 4 线程，Prefill -- Decode tok/s）**：

| 输入长度 | 64 tok | 256 tok | 1024 tok |
|---|---|---|---|
| MNN-LLM CPU | 225.19 -- 53.65 | 298.89 -- 52.45 | 236.76 -- 45.70 |
| MNN-LLM OpenCL | 153.42 -- 26.92 | 166.82 -- 26.33 | 237.31 -- 20.87 |
| llama.cpp CPU | 46.22 -- 30.05 | 42.06 -- 26.39 | 37.37 -- 22.07 |
| MLC-LLM OpenCL | 137.6 -- 25 | 146.3 -- 19.5 | 83.5 -- 11.9 |

**Qwen2-7B（CPU 4 线程）**：Prefill 59~67 tok/s，Decode 10~13 tok/s；**Llama3-8B**：Prefill 53~65 tok/s，Decode 9~11 tok/s。

**其他参考点**：8Gen1 + 1.8B 模型 Decode 35+ tok/s；Llama3.1-8B prefill 约 28 tok/s（社区反馈）；混合存储使 7B 模型 DRAM 占用降 2GB+ 无明显减速。

### 8.2 性能数据解读（工程视角）

1. **Prefill 优势远大于 Decode**（8.6× vs 2.3×）：Prefill 是计算受限，MNN 的汇编级浮点 kernel + 数据重排发挥空间大；Decode 是访存受限，各家框架都逼近内存带宽理论极限，差距天然收窄。
2. **CPU 在小模型上反超 GPU**：1.5B 模型 CPU Decode（45-53）明显高于 OpenCL（20-27）——小模型 GPU kernel 启动与访存开销占比高，且 CPU 4 大核带宽聚合可观。**选型建议：≤2B 模型优先 CPU 后端，7B+ 或长上下文再评估 GPU**。
3. **厂商自测数据需谨慎**：上述为阿里团队测试结果（对比框架版本固定），不同设备/量化格式/线程数结论可能偏移，落地前务必用 `llm_bench` 在目标机型实测（OpenCL 记得跑第二次）。
4. **多模态内存参考**：Qwen2.5-Omni-3B 保留 7B 约 90% 多模态能力，内存占用减半（服务端 60.2GB→28.2GB；端侧 int4 后 6GB 内存手机可跑 7B 文本模型）。

---

## 九、App 生态与分发

| 产品 | 形态 | 说明 |
|---|---|---|
| **MNN Chat**（MnnLlmChat） | Android/iOS App | 全模态离线应用：文生文 / 图生文 / 音生文 / 文生图；内置模型市场（0.8.3 版本模型目录），从 CDN/ModelScope/HF 一键下载；mmap 加速加载；聊天历史本地库。v0.1 于 2025-02 开源，演进活跃 |
| **MNN LLM iOS** | iOS App | 多模态 LLM，Metal 后端 |
| **MNN TaoAvatar** | Android App | 3D 数字人离线对话：LLM + ASR + TTS + A2BS + NNR 全部本地运行 |
| **MNN-Sana-Edit-V2** | App | 基于 Sana 的卡通风格图片编辑 |
| **taobao-mnn（HF 组织）** | 模型分发 | 24+ 个 MNN 打包模型集合（Gemma/LFM/MiniCPM/DeepSeek-R1-Qwen/Qwen2.5-Coder 等），持续更新 |

> 官方 App 明确提示：仅在 OnePlus 13 / 小米 14 Ultra 等高端机充分测试，低端设备可能慢/不稳定——端侧 LLM 的设备分级（device tiering）是业务落地必答题。

---

## 十、工程实践建议与注意事项

### 10.1 部署决策清单

| 决策点 | 建议 |
|---|---|
| 模型档位 | 6GB 内存机型：≤4B int4；8-12GB：7-8B int4； Decode 速度要求 >20 tok/s：≤2B |
| 后端选择 | 默认 CPU 4 线程起步；≤2B 模型 CPU 通常最优；长上下文大模型测 OpenCL/Metal |
| 量化配置 | `--quant_bit 4 --quant_block 128 --hqq`；lm_head 用 `--lm_quant_bit 8` 保生成质量 |
| KV 策略 | 4B+ 模型 `attention_mode: 14`（FA+TQ4）；多轮会话必开 `reuse_kv` |
| 内存防线 | 手机端 `use_mmap: true` + 按需 `kvcache_mmap` + `chunk` 分块 |
| 系统提示词 | 长且固定的 system prompt 用 prefix KV 磁盘缓存（rollback 机制） |
| 重复文本 | 启用 penalty 采样器（`repetition_penalty: 1.05~1.5`） |

### 10.2 已知坑点

1. **OpenCL 首跑慢**：tuning 过程生成缓存，benchmark/生产预热都需第二次运行。
2. **OpenCL thread_num=68**：非线程语义，是新手的经典困惑点。
3. **TQ3/TQ4 仅 CPU**：GPU 后端不支持的量化模式会静默回退或报错，跨后端切换需核对 `attention_mode` 支持矩阵。
4. **dynamic_option 的 8+n 变体**：短 prompt（<300 token）Prefill 显著变慢，聊天场景慎用。
5. **Hexagon 后端限制**：仅 4-bit 对称量化 + Transformer C4 导出路径。
6. **文档滞后**：新特性以 GitHub release notes 与源码为准；文档站旧链接部分 404。
7. **新模型适配节奏**：依赖官方更新 llmexport；自研/魔改结构需写导出脚本。
8. **精度对齐**：导出后用 `--test "query"` 先验一把；对比 FP32 可逐层 dump（QNN 后端亦有中间张量 dump 工具）。

### 10.3 与竞品定位对比

| 维度 | MNN-LLM | llama.cpp | MLC-LLM | fastllm |
|---|---|---|---|---|
| CPU Prefill | **最强（8.6×）** | 一般 | — | 弱（20.5×差距） |
| CPU Decode | 强（2.3×） | 中 | — | 弱 |
| GPU 稳定性 | 好（不易 crash） | OpenCL 弱 | 曾有卡死问题 | — |
| 量化生态 | int4/8 + KV量化 + HQQ/AWQ/GPTQ | GGUF K-quants 最丰富 | q4f16 等 | int4/8 |
| 多模态 | **VL/Omni/语音原生** | 视觉有限 | 有限 | 无 |
| 模型格式 | 自有 .mnn（需导出） | GGUF（社区海量现成） | 需编译打包 | 需转换 |
| 附加能力 | LoRA 并存/投机解码/端侧训练 | 生态工具最多 | TVM 自动调优 | 轻量 |
| 特色 | **一引擎通吃 CV+LLM+Diffusion** | 通用性/社区 | 编译优化研究前沿 | 简单 |

**选型结论**：需要 Prefill 敏感（长 prompt、RAG、文档类）或多模态、或与既有 MNN CV 业务共享引擎 → MNN-LLM；需要最快拿到社区海量 GGUF 模型 → llama.cpp；两者也可并存（GGUF 生态选模型，MNN 做性能敏感路径）。

---

## 十一、学习资源与路径

| 资源 | 链接 |
|---|---|
| **MNN-LLM 论文**（本报告 §4 技术细节来源） | https://www.arxiv.org/pdf/2506.10443 |
| 官方 LLM 文档（部署/config 参考） | https://mnn-docs.readthedocs.io/en/latest/transformers/llm.html |
| 源码 transformers/llm | https://github.com/alibaba/MNN/tree/master/transformers/llm |
| MNN Chat App 源码 | 仓库 `apps/Android/MnnLlmChat` 与 `apps/iOS/MNNLLMChat` |
| 阿里技术博客（含性能对比原始数据） | https://blog.csdn.net/Taobaojishu/article/details/143949568 |
| 官方预转换模型 | ModelScope `MNN` 组织 / HuggingFace `taobao-mnn` 组织 |
| 官网 | https://www.mnn.zone |

**推荐实操路径**（约 2~3 天）：

1. **30 分钟跑通**：ModelScope 下载 Qwen3-0.6B-MNN 预转换模型 → Android 真机 adb push → llm_demo 交互；
2. **半天摸性能**：llm_bench 对比 CPU 4 线程 vs OpenCL、`attention_mode` 8/10/14 三档、`dynamic_option` 0/2，记录目标机型基线；
3. **一天走全链路**：自行 llmexport 导出一个 1.5B 模型（对比 `--hqq` 与默认量化精度）→ 理解每个产物文件的作用；
4. **半天读源码**：`engine/cpp` 的 Llm 主流程（prefill/decode 循环）+ KV Manager（量化与 mmap）；
5. **延伸**：精读论文 §4（混合存储与量化公式）→ 对照 Wiki 中 [[模型量化]] 与 [[量化算法流派]] 笔记，梳理 MNN 动态量化 / KV-FP8 / TurboQuant 与 GPTQ/AWQ/K-quants 的流派关系。

---

*报告基于 MNN-LLM 论文（arXiv 2506.10443）、GitHub 仓库（3.6.1，2026-09）、官方文档、阿里技术博客等公开资料整理。性能数据均为官方/论文自测环境（骁龙 8 Gen 3 等）结果，实际表现因设备、模型、量化配置而异，落地前请以 llm_bench 目标机型实测为准。*
