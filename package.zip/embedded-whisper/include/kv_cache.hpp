/**
 * @file kv_cache.hpp
 * @brief KV Cache Manager for efficient autoregressive decoding
 * @description 在Whisper模型的自回归解码过程中，KV Cache用于缓存
 * 之前计算过的Key和Value张量，避免重复计算，显著提升推理速度
 */

#ifndef KV_CACHE_HPP
#define KV_CACHE_HPP

#include <onnxruntime_cxx_api.h>
#include <vector>
#include <memory>
#include <cstring>
#include <algorithm>

namespace embedded_whisper {

/**
 * @brief KV Cache管理器类
 * @description 管理Whisper模型的Key-Value缓存，实现zero-copy更新
 * 以最大化嵌入式平台的内存效率和推理速度
 */
class KVCacheManager {
public:
    /**
     * @brief 构造函数
     * @param ort_session ONNX Runtime会话
     * @param num_layers 层数 (Whisper tiny为4层)
     * @param num_heads 注意力头数
     * @param head_dim 注意力头维度
     * @param max_length 最大序列长度
     */
    KVCacheManager(Ort::Session& ort_session,
                   int num_layers,
                   int num_heads,
                   int head_dim,
                   int max_length = 448);

    /**
     * @brief 析构函数
     */
    ~KVCacheManager();

    /**
     * @brief 初始化KV Cache
     * @description 创建空的KV Cache张量，用于第一次解码
     */
    void Initialize();

    /**
     * @brief 获取当前KV Cache作为输入
     * @return KV Cache张量向量
     */
    std::vector<Ort::Value> GetInputCache();

    /**
     * @brief 更新KV Cache
     * @param present_kv 最新的KV Cache输出
     * @description 使用present_kv更新内部缓存，实现zero-copy
     */
    void UpdateCache(std::vector<Ort::Value>& present_kv);

    /**
     * @brief 重置KV Cache到初始状态
     */
    void Reset();

    /**
     * @brief 获取当前序列长度
     * @return 当前缓存的token数量
     */
    int GetCurrentLength() const { return current_length_; }

    /**
     * @brief 检查是否达到最大长度
     * @return 是否已满
     */
    bool IsFull() const { return current_length_ >= max_length_; }

private:
    /**
     * @brief 创建空张量
     * @param shape 张量形状
     * @return 创建的ONNX张量
     */
    Ort::Value CreateEmptyTensor(const std::vector<int64_t>& shape);

    /**
     * @brief 预分配内存池
     */
    void PreAllocate();

    // ONNX Runtime references
    Ort::Session& session_;
    Ort::MemoryInfo memory_info_;

    // Cache configuration
    const int num_layers_;
    const int num_heads_;
    const int head_dim_;
    const int max_length_;
    int current_length_;

    // Cached tensors (ping-pong buffer strategy)
    // 存储当前的past_key_values
    std::vector<Ort::Value> past_kv_cache_;

    // Tensor shapes
    // K shape: [batch, heads, seq_len, head_dim]
    // V shape: [batch, heads, seq_len, head_dim]
    const std::vector<int64_t> k_shape_;
    const std::vector<int64_t> v_shape_;

    // 是否已初始化
    bool is_initialized_;

    // 内存池用于避免频繁分配
    std::vector<float*> k_buffer_pool_;
    std::vector<float*> v_buffer_pool_;
};

} // namespace embedded_whisper

#endif // KV_CACHE_HPP
