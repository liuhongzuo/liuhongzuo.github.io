/**
 * @file audio_preprocessor.hpp
 * @brief Audio preprocessing for Whisper model
 * @description 实现Log-Mel Spectrogram特征提取，将原始音频转换为
 * Whisper模型所需的输入格式
 */

#ifndef AUDIO_PREPROCESSOR_HPP
#define AUDIO_PREPROCESSOR_HPP

#include <vector>
#include <string>
#include <cmath>
#include <complex>
#include <algorithm>
#include <fstream>
#include <cstdint>

namespace embedded_whisper {

/**
 * @brief 音频预处理配置
 */
struct AudioConfig {
    int sample_rate = 16000;          // Whisper期望的采样率
    int n_fft = 400;                  // FFT窗口大小
    int hop_length = 160;            // 帧移 (10ms at 16kHz)
    int n_mels = 80;                  // Mel滤波器数量
    int n_ctx = 3000;                 // 上下文帧数 (30秒)
    int n_frames = 3000;              // 输出帧数
    float f_min = 0.0f;               // 最小频率
    float f_max = 8000.0f;            // 最大频率
    int window_size = 400;            // 窗口大小
};

/**
 * @brief 音频预处理类
 * @description 将原始PCM音频转换为Log-Mel Spectrogram
 * 针对嵌入式平台进行了优化，无需外部依赖
 */
class AudioPreprocessor {
public:
    /**
     * @brief 构造函数
     * @param config 音频配置
     */
    explicit AudioPreprocessor(const AudioConfig& config = AudioConfig());

    /**
     * @brief 析构函数
     */
    ~AudioPreprocessor();

    /**
     * @brief 从PCM数据提取Log-Mel Spectrogram
     * @param pcm_data 原始PCM数据 (float, 16kHz, mono)
     * @param num_samples 样本数量
     * @return Log-Mel Spectrogram矩阵 [n_mels, n_frames]
     */
    std::vector<std::vector<float>> ExtractLogMelSpectrogram(
        const float* pcm_data,
        size_t num_samples);

    /**
     * @brief 从WAV文件加载音频
     * @param filename WAV文件路径
     * @return PCM float数据
     */
    std::vector<float> LoadWavFile(const std::string& filename);

    /**
     * @brief 从原始音频数据加载
     * @param filename 原始音频文件路径
     * @return PCM float数据
     */
    std::vector<float> LoadRawAudio(const std::string& filename);

    /**
     * @brief 重采样音频到目标采样率
     * @param data 输入音频数据
     * @param from_rate 原始采样率
     * @param to_rate 目标采样率
     * @return 重采样后的数据
     */
    std::vector<float> Resample(const std::vector<float>& data,
                               int from_rate,
                               int to_rate);

    /**
     * @brief 归一化音频数据
     * @param data 音频数据
     */
    void NormalizeAudio(std::vector<float>& data);

    /**
     * @brief 获取最后处理的特征
     * @return Log-Mel特征矩阵
     */
    const std::vector<std::vector<float>>& GetLastFeatures() const {
        return last_features_;
    }

private:
    /**
     * @brief 计算短时傅里叶变换 (STFT)
     */
    std::vector<std::vector<std::complex<float>>> ComputeSTFT(
        const float* audio,
        size_t length);

    /**
     * @brief 计算Mel滤波器组
     */
    void ComputeMelFilterbank();

    /**
     * @brief 应用Mel滤波器组
     */
    std::vector<std::vector<float>> ApplyMelFilterbank(
        const std::vector<std::vector<std::complex<float>>>& stft_result);

    /**
     * @brief 计算对数
     */
    std::vector<std::vector<float>> ComputeLogMagnitude(
        const std::vector<std::vector<float>>& mel_spec);

    /**
     * @brief 填充或截断到固定长度
     */
    std::vector<std::vector<float>> PadOrTruncate(
        const std::vector<std::vector<float>>& features);

    // 音频配置
    AudioConfig config_;

    // Mel滤波器组
    std::vector<std::vector<float>> mel_filterbank_;

    // 最后处理的特征
    std::vector<std::vector<float>> last_features_;

    // 预计算的窗函数
    std::vector<float> hann_window_;
};

} // namespace embedded_whisper

#endif // AUDIO_PREPROCESSOR_HPP
