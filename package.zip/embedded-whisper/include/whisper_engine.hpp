/**
 * @file whisper_engine.hpp
 * @brief Whisper inference engine for embedded platforms
 * @description 使用ONNX Runtime在嵌入式平台上高效运行Whisper-tiny模型
 * 支持KV Cache优化，实现实时语音转文字
 */

#ifndef WHISPER_ENGINE_HPP
#define WHISPER_ENGINE_HPP

#include <onnxruntime_cxx_api.h>
#include <memory>
#include <string>
#include <vector>
#include <chrono>
#include <iostream>

#include "kv_cache.hpp"
#include "audio_preprocessor.hpp"

namespace embedded_whisper {

/**
 * @brief Whisper模型配置
 */
struct WhisperConfig {
    // 模型路径
    std::string encoder_model_path = "models/encoder.onnx";
    std::string decoder_model_path = "models/decoder.onnx";

    // 模型参数 (Whisper tiny)
    int num_layers = 4;
    int num_heads = 4;
    int head_dim = 384;  // 1536 / 4
    int hidden_size = 384;
    int vocab_size = 51864;
    int max_length = 448;

    // 推理配置
    int num_threads = 1;
    bool use_interleaved = false;

    // 解码配置
    float temperature = 0.0f;  // 0.0 = greedy, >0 = sampling
    int max_tokens = 448;
    float logprob_threshold = -1.0f;
    float no_speech_threshold = 0.6f;

    // 特殊token ID
    int start_token_id = 50258;  // <|startoftranscript|>
    int end_token_id = 50257;     // <|endoftext|>
    int no_timestamps_token_id = 50361;
};

/**
 * @brief 推理结果
 */
struct InferenceResult {
    std::string text;
    std::vector<int> tokens;
    float inference_time_ms;
    int num_tokens_generated;
};

/**
 * @brief Whisper推理引擎类
 * @description 封装ONNX Runtime会话管理、模型推理和KV Cache
 * 针对嵌入式平台进行了内存和速度优化
 */
class WhisperEngine {
public:
    /**
     * @brief 构造函数
     * @param config Whisper配置
     */
    explicit WhisperEngine(const WhisperConfig& config = WhisperConfig());

    /**
     * @brief 析构函数
     */
    ~WhisperEngine();

    /**
     * @brief 初始化引擎
     * @return 是否成功
     */
    bool Initialize();

    /**
     * @brief 加载模型
     * @return 是否成功
     */
    bool LoadModels();

    /**
     * @brief 推理 (单次调用)
     * @param audio_features Log-Mel特征
     * @return 推理结果
     */
    InferenceResult Infer(const std::vector<std::vector<float>>& audio_features);

    /**
     * @brief 推理 (从音频文件)
     * @param audio_file 音频文件路径
     * @return 推理结果
     */
    InferenceResult InferFromFile(const std::string& audio_file);

    /**
     * @brief 重置解码状态
     */
    void Reset();

    /**
     * @brief 获取引擎状态描述
     * @return 状态字符串
     */
    std::string GetStatus() const;

    /**
     * @brief 检查是否已初始化
     * @return 是否就绪
     */
    bool IsReady() const { return is_ready_; }

private:
    /**
     * @brief 编码器推理
     * @param input_features 输入特征
     * @return 编码器输出hidden states
     */
    std::vector<Ort::Value> RunEncoder(
        const std::vector<std::vector<float>>& input_features);

    /**
     * @brief 解码器推理 (支持KV Cache)
     * @param input_ids 输入token ID
     * @param encoder_output 编码器输出
     * @param kv_cache KV Cache
     * @return 解码器输出(logits + present_kv)
     */
    std::vector<Ort::Value> RunDecoder(
        const std::vector<int64_t>& input_ids,
        const std::vector<Ort::Value>& encoder_output,
        std::vector<Ort::Value>& kv_cache);

    /**
     * @brief 贪婪解码
     * @param logits Logits张量
     * @return 预测的token ID
     */
    int64_t GreedyDecode(const Ort::Value& logits);

    /**
     * @brief 准备解码器输入
     */
    std::vector<int64_t> PrepareDecoderInput(
        int64_t prev_token,
        bool is_first);

    /**
     * @brief 转换为ONNX张量
     */
    Ort::Value VectorToTensor(
        const std::vector<std::vector<float>>& data,
        const std::vector<int64_t>& shape);

    // 配置
    WhisperConfig config_;

    // ONNX Runtime
    std::unique_ptr<Ort::Env> env_;
    std::unique_ptr<Ort::SessionOptions> session_options_;
    std::unique_ptr<Ort::Session> encoder_session_;
    std::unique_ptr<Ort::Session> decoder_session_;

    // KV Cache管理器
    std::unique_ptr<KVCacheManager> kv_cache_manager_;

    // 音频预处理器
    std::unique_ptr<AudioPreprocessor> audio_preprocessor_;

    // 模型输入输出名称
    std::vector<char*> encoder_input_names_;
    std::vector<char*> encoder_output_names_;
    std::vector<char*> decoder_input_names_;
    std::vector<char*> decoder_output_names_;

    // 状态
    bool is_ready_;
    bool models_loaded_;

    // 性能统计
    struct PerformanceStats {
        int64_t total_inferences = 0;
        int64_t total_tokens = 0;
        double total_time_ms = 0.0;
    } stats_;
};

} // namespace embedded_whisper

#endif // WHISPER_ENGINE_HPP
