/**
 * @file audio_preprocessor.cpp
 * @brief Audio preprocessing implementation for Whisper
 * @description 实现Log-Mel Spectrogram特征提取，针对嵌入式平台
 * 进行了优化，无需外部FFT库
 */

#include "audio_preprocessor.hpp"
#include <cassert>
#include <cstddef>

namespace embedded_whisper {

// Helper function for complex numbers
namespace {
    std::complex<float> ComplexExp(float angle) {
        return std::complex<float>(std::cos(angle), std::sin(angle));
    }
}

AudioPreprocessor::AudioPreprocessor(const AudioConfig& config)
    : config_(config)
{
    // 预计算Hann窗函数
    hann_window_.resize(config_.window_size);
    for (int i = 0; i < config_.window_size; ++i) {
        hann_window_[i] = 0.5f * (1.0f - std::cos(2.0f * M_PI * i / (config_.window_size - 1)));
    }

    // 预计算Mel滤波器组
    ComputeMelFilterbank();
}

AudioPreprocessor::~AudioPreprocessor() = default;

std::vector<float> AudioPreprocessor::LoadWavFile(const std::string& filename) {
    // 简单的WAV文件加载器 (仅支持PCM 16-bit mono)
    std::ifstream file(filename, std::ios::binary);
    if (!file.is_open()) {
        throw std::runtime_error("Cannot open WAV file: " + filename);
    }

    // 读取WAV头
    char riff[4];
    file.read(riff, 4);
    if (std::string(riff, 4) != "RIFF") {
        throw std::runtime_error("Invalid WAV file: missing RIFF header");
    }

    // 跳过到data chunk
    file.seekg(44, std::ios::beg);

    // 读取原始数据
    std::vector<int16_t> pcm_int16;
    int16_t sample;
    while (file.read(reinterpret_cast<char*>(&sample), sizeof(sample))) {
        pcm_int16.push_back(sample);
    }

    // 转换为float并归一化
    std::vector<float> pcm_float;
    pcm_float.reserve(pcm_int16.size());
    for (const auto& s : pcm_int16) {
        pcm_float.push_back(static_cast<float>(s) / 32768.0f);
    }

    // 重采样如果需要
    // 假设WAV文件是44.1kHz，需要重采样到16kHz
    // 这里简化处理，假设已经是16kHz
    return pcm_float;
}

std::vector<float> AudioPreprocessor::LoadRawAudio(const std::string& filename) {
    // 加载原始PCM文件 (16kHz mono float)
    std::ifstream file(filename, std::ios::binary);
    if (!file.is_open()) {
        throw std::runtime_error("Cannot open audio file: " + filename);
    }

    std::vector<float> data;
    float sample;
    while (file.read(reinterpret_cast<char*>(&sample), sizeof(sample))) {
        data.push_back(sample);
    }

    return data;
}

std::vector<float> AudioPreprocessor::Resample(const std::vector<float>& data,
                                                int from_rate,
                                                int to_rate) {
    if (from_rate == to_rate) {
        return data;
    }

    // 简单的线性重采样
    float ratio = static_cast<float>(from_rate) / to_rate;
    size_t new_length = static_cast<size_t>(data.size() / ratio);

    std::vector<float> resampled(new_length);
    for (size_t i = 0; i < new_length; ++i) {
        float src_idx = i * ratio;
        size_t idx0 = static_cast<size_t>(src_idx);
        size_t idx1 = std::min(idx0 + 1, data.size() - 1);
        float frac = src_idx - idx0;

        resampled[i] = data[idx0] * (1.0f - frac) + data[idx1] * frac;
    }

    return resampled;
}

void AudioPreprocessor::NormalizeAudio(std::vector<float>& data) {
    if (data.empty()) return;

    // 找最大值
    float max_val = 0.0f;
    for (const auto& sample : data) {
        max_val = std::max(max_val, std::abs(sample));
    }

    // 归一化
    if (max_val > 0.0f) {
        for (auto& sample : data) {
            sample /= max_val;
        }
    }
}

std::vector<std::vector<float>> AudioPreprocessor::ExtractLogMelSpectrogram(
    const float* pcm_data,
    size_t num_samples) {

    // 1. 计算STFT
    auto stft_result = ComputeSTFT(pcm_data, num_samples);

    // 2. 应用Mel滤波器组
    auto mel_spec = ApplyMelFilterbank(stft_result);

    // 3. 计算对数幅度
    auto log_mel = ComputeLogMagnitude(mel_spec);

    // 4. 填充或截断到固定长度
    last_features_ = PadOrTruncate(log_mel);

    return last_features_;
}

void AudioPreprocessor::ComputeMelFilterbank() {
    // 创建Mel滤波器组
    mel_filterbank_.resize(config_.n_mels, std::vector<float>(config_.n_fft / 2 + 1, 0.0f));

    // 计算频率到Mel的转换
    auto hz_to_mel = [](float hz) {
        return 2595.0f * std::log10(1.0f + hz / 700.0f);
    };

    auto mel_to_hz = [](float mel) {
        return 700.0f * (std::pow(10.0f, mel / 2595.0f) - 1.0f);
    };

    // 计算频率点
    float f_min_mel = hz_to_mel(config_.f_min);
    float f_max_mel = hz_to_mel(config_.f_max);

    std::vector<float> freqs(config_.n_fft / 2 + 1);
    for (int i = 0; i <= config_.n_fft / 2; ++i) {
        freqs[i] = static_cast<float>(i) * config_.sample_rate / config_.n_fft;
    }

    // 计算每个Mel滤波器的中心频率
    std::vector<float> mel_points(config_.n_mels + 2);
    for (int i = 0; i < config_.n_mels + 2; ++i) {
        mel_points[i] = f_min_mel + (f_max_mel - f_min_mel) * i / (config_.n_mels + 1);
    }

    // 转换为Hz
    std::vector<float> bin_points(config_.n_mels + 2);
    for (int i = 0; i < config_.n_mels + 2; ++i) {
        bin_points[i] = mel_to_hz(mel_points[i]) * config_.n_fft / config_.sample_rate;
    }

    // 创建三角形滤波器
    for (int i = 0; i < config_.n_mels; ++i) {
        for (int j = 0; j <= config_.n_fft / 2; ++j) {
            float freq = static_cast<float>(j) * config_.sample_rate / config_.n_fft;
            float left = bin_points[i];
            float center = bin_points[i + 1];
            float right = bin_points[i + 2];

            float weight = 0.0f;
            if (freq >= left && freq <= center) {
                weight = (freq - left) / (center - left);
            } else if (freq >= center && freq <= right) {
                weight = (right - freq) / (right - center);
            }

            mel_filterbank_[i][j] = weight;
        }
    }
}

std::vector<std::vector<std::complex<float>>> AudioPreprocessor::ComputeSTFT(
    const float* audio,
    size_t length) {

    int n_frames = static_cast<int>((length - config_.window_size) / config_.hop_length) + 1;

    // 存储结果: [frame, freq_bin]
    std::vector<std::vector<std::complex<float>>> result(
        n_frames,
        std::vector<std::complex<float>>(config_.n_fft / 2 + 1)
    );

    // 对每一帧进行FFT
    std::vector<float> windowed_audio(config_.window_size);
    std::vector<std::complex<float>> fft_buffer(config_.n_fft);

    for (int frame = 0; frame < n_frames; ++frame) {
        int start = frame * config_.hop_length;

        // 加窗
        for (int i = 0; i < config_.window_size; ++i) {
            if (start + i < length) {
                windowed_audio[i] = audio[start + i] * hann_window_[i];
            } else {
                windowed_audio[i] = 0.0f;
            }
        }

        // 填充FFT缓冲区
        for (int i = 0; i < config_.n_fft; ++i) {
            if (i < config_.window_size) {
                fft_buffer[i] = windowed_audio[i];
            } else {
                fft_buffer[i] = 0.0f;
            }
        }

        // 简单的DFT实现 (对于嵌入式可以优化为定点FFT)
        for (int k = 0; k <= config_.n_fft / 2; ++k) {
            std::complex<float> sum = 0.0f;
            for (int n = 0; n < config_.n_fft; ++n) {
                float angle = -2.0f * M_PI * k * n / config_.n_fft;
                sum += fft_buffer[n] * ComplexExp(angle);
            }
            result[frame][k] = sum;
        }
    }

    return result;
}

std::vector<std::vector<float>> AudioPreprocessor::ApplyMelFilterbank(
    const std::vector<std::vector<std::complex<float>>>& stft_result) {

    int n_frames = static_cast<int>(stft_result.size());
    std::vector<std::vector<float>> mel_spec(
        n_frames,
        std::vector<float>(config_.n_mels, 0.0f)
    );

    // 对每一帧应用Mel滤波器
    for (int frame = 0; frame < n_frames; ++frame) {
        // 计算幅度谱
        std::vector<float> mag_spec(config_.n_fft / 2 + 1);
        for (int i = 0; i <= config_.n_fft / 2; ++i) {
            mag_spec[i] = std::abs(stft_result[frame][i]);
            mag_spec[i] = mag_spec[i] * mag_spec[i];  // 功率谱
        }

        // 应用Mel滤波器
        for (int m = 0; m < config_.n_mels; ++m) {
            float sum = 0.0f;
            for (int i = 0; i <= config_.n_fft / 2; ++i) {
                sum += mag_spec[i] * mel_filterbank_[m][i];
            }
            mel_spec[frame][m] = sum;
        }
    }

    return mel_spec;
}

std::vector<std::vector<float>> AudioPreprocessor::ComputeLogMagnitude(
    const std::vector<std::vector<float>>& mel_spec) {

    int n_frames = static_cast<int>(mel_spec.size());
    std::vector<std::vector<float>> log_mel(
        n_frames,
        std::vector<float>(config_.n_mels)
    );

    float min_val = 1e-10f;

    for (int frame = 0; frame < n_frames; ++frame) {
        for (int m = 0; m < config_.n_mels; ++m) {
            float val = std::max(mel_spec[frame][m], min_val);
            log_mel[frame][m] = std::log10(val);
        }
    }

    return log_mel;
}

std::vector<std::vector<float>> AudioPreprocessor::PadOrTruncate(
    const std::vector<std::vector<float>>& features) {

    int n_frames = static_cast<int>(features.size());
    std::vector<std::vector<float>> result(
        config_.n_ctx,
        std::vector<float>(config_.n_mels, 0.0f)
    );

    if (n_frames >= config_.n_ctx) {
        // 截断
        for (int i = 0; i < config_.n_ctx; ++i) {
            result[i] = features[i];
        }
    } else {
        // 填充 (在中间填充)
        int start = (config_.n_ctx - n_frames) / 2;
        for (int i = 0; i < n_frames; ++i) {
            result[start + i] = features[i];
        }
    }

    return result;
}

} // namespace embedded_whisper
