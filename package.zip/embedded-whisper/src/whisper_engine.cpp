/**
 * @file whisper_engine.cpp
 * @brief Whisper inference engine implementation
 * @description 实现Whisper模型的完整推理流程，包括编码器、解码器和
 * KV Cache管理，针对嵌入式平台进行优化
 */

#include "whisper_engine.hpp"
#include <algorithm>
#include <cmath>
#include <fstream>

namespace embedded_whisper {

// Tokenizer简单的实现 (实际项目中应该使用完整的tokenizer)
namespace {
    // Whisper tiny的词汇表是BPE，这里提供基础实现
    std::string DecodeToken(int token_id) {
        // 简化版本：返回空字符串，实际应该查表
        return "";
    }

    const char* TOKENIZER_VOCAB[] = {
        // 简化版本
    };
}

WhisperEngine::WhisperEngine(const WhisperConfig& config)
    : config_(config)
    , is_ready_(false)
    , models_loaded_(false)
{
    // 初始化ONNX Runtime环境
    env_ = std::make_unique<Ort::Env>(ORT_LOGGING_LEVEL_WARNING, "WhisperInference");

    // 配置Session选项 (针对嵌入式优化)
    session_options_ = std::make_unique<Ort::SessionOptions>();

    // 设置线程数
    session_options_->SetIntraOpNumThreads(config_.num_threads);
    session_options_->SetInterOpNumThreads(1);

    // 启用图优化
    session_options_->SetGraphOptimizationLevel(
        GraphOptimizationLevel::ORT_ENABLE_ALL);

    // 顺序执行模式 (节省内存)
    session_options_->SetExecutionMode(ExecutionMode::ORT_SEQUENTIAL);

    // 内存优化
    session_options_->SetMemoryPatternOptimizationLevel(true);
    session_options_->SetCpuArenaAllocatorType(ArenaAllocatorType::kNone);

    // 创建音频预处理器
    audio_preprocessor_ = std::make_unique<AudioPreprocessor>();
}

WhisperEngine::~WhisperEngine() {
    // 释放ONNX资源
    for (auto* name : encoder_input_names_) {
        delete[] name;
    }
    for (auto* name : encoder_output_names_) {
        delete[] name;
    }
    for (auto* name : decoder_input_names_) {
        delete[] name;
    }
    for (auto* name : decoder_output_names_) {
        delete[] name;
    }
}

bool WhisperEngine::Initialize() {
    if (models_loaded_) {
        return true;
    }

    // 加载模型
    if (!LoadModels()) {
        std::cerr << "Failed to load models" << std::endl;
        return false;
    }

    // 创建KV Cache管理器
    kv_cache_manager_ = std::make_unique<KVCacheManager>(
        *encoder_session_,  // 临时使用encoder session
        config_.num_layers,
        config_.num_heads,
        config_.head_dim,
        config_.max_length
    );

    is_ready_ = true;
    return true;
}

bool WhisperEngine::LoadModels() {
    try {
        // 加载编码器模型
        encoder_session_ = std::make_unique<Ort::Session>(
            *env_,
            config_.encoder_model_path.c_str(),
            *session_options_
        );

        // 加载解码器模型
        decoder_session_ = std::make_unique<Ort::Session>(
            *env_,
            config_.decoder_model_path.c_str(),
            *session_options_
        );

        // 获取输入输出名称
        Ort::AllocatorWithDefaultOptions allocator;

        // Encoder input names
        size_t num_encoder_inputs = encoder_session_->GetInputCount();
        for (size_t i = 0; i < num_encoder_inputs; ++i) {
            auto name = encoder_session_->GetInputNameAllocated(i, allocator);
            encoder_input_names_.push_back(name.release());
        }

        // Encoder output names
        size_t num_encoder_outputs = encoder_session_->GetOutputCount();
        for (size_t i = 0; i < num_encoder_outputs; ++i) {
            auto name = encoder_session_->GetOutputNameAllocated(i, allocator);
            encoder_output_names_.push_back(name.release());
        }

        // Decoder input names
        size_t num_decoder_inputs = decoder_session_->GetInputCount();
        for (size_t i = 0; i < num_decoder_inputs; ++i) {
            auto name = decoder_session_->GetInputNameAllocated(i, allocator);
            decoder_input_names_.push_back(name.release());
        }

        // Decoder output names
        size_t num_decoder_outputs = decoder_session_->GetOutputCount();
        for (size_t i = 0; i < num_decoder_outputs; ++i) {
            auto name = decoder_session_->GetOutputNameAllocated(i, allocator);
            decoder_output_names_.push_back(name.release());
        }

        models_loaded_ = true;
        return true;

    } catch (const Ort::Exception& e) {
        std::cerr << "ONNX Runtime error: " << e.what() << std::endl;
        return false;
    }
}

InferenceResult WhisperEngine::Infer(
    const std::vector<std::vector<float>>& audio_features) {

    if (!is_ready_) {
        throw std::runtime_error("Engine not initialized");
    }

    auto start_time = std::chrono::high_resolution_clock::now();

    // 1. 运行编码器
    auto encoder_output = RunEncoder(audio_features);

    // 2. 初始化KV Cache
    kv_cache_manager_->Initialize();

    // 3. 自回归解码
    std::vector<int64_t> input_ids = {config_.start_token_id};
    std::vector<int> generated_tokens;
    bool is_first = true;

    for (int i = 0; i < config_.max_tokens; ++i) {
        // 获取KV Cache
        auto kv_cache = kv_cache_manager_->GetInputCache();

        // 运行解码器
        auto decoder_output = RunDecoder(input_ids, encoder_output, kv_cache);

        // 获取logits (第一个输出)
        auto& logits = decoder_output[0];

        // 贪婪解码
        int64_t next_token = GreedyDecode(logits);

        // 检查结束条件
        if (next_token == config_.end_token_id) {
            break;
        }

        generated_tokens.push_back(static_cast<int>(next_token));

        // 更新KV Cache
        std::vector<Ort::Value> present_kv;
        for (size_t j = 1; j < decoder_output.size(); ++j) {
            present_kv.push_back(std::move(decoder_output[j]));
        }
        kv_cache_manager_->UpdateCache(present_kv);

        // 更新输入
        input_ids.clear();
        input_ids.push_back(next_token);
        is_first = false;
    }

    // 4. 构建结果
    InferenceResult result;
    result.tokens = generated_tokens;
    result.num_tokens_generated = generated_tokens.size();

    // 简单的token转文本 (实际应该用tokenizer)
    // 这里生成占位符
    result.text = "[Transcription with " +
                  std::to_string(result.num_tokens_generated) +
                  " tokens]";

    // 计算推理时间
    auto end_time = std::chrono::high_resolution_clock::now();
    result.inference_time_ms = std::chrono::duration<double, std::milli>(
        end_time - start_time).count();

    // 更新统计
    stats_.total_inferences++;
    stats_.total_tokens += result.num_tokens_generated;
    stats_.total_time_ms += result.inference_time_ms;

    return result;
}

InferenceResult WhisperEngine::InferFromFile(const std::string& audio_file) {
    // 1. 加载音频
    std::vector<float> audio_data;
    try {
        audio_data = audio_preprocessor_->LoadWavFile(audio_file);
    } catch (...) {
        // 尝试加载原始音频
        audio_data = audio_preprocessor_->LoadRawAudio(audio_file);
    }

    // 2. 预处理
    audio_preprocessor_->NormalizeAudio(audio_data);
    auto features = audio_preprocessor_->ExtractLogMelSpectrogram(
        audio_data.data(),
        audio_data.size()
    );

    // 3. 推理
    return Infer(features);
}

void WhisperEngine::Reset() {
    if (kv_cache_manager_) {
        kv_cache_manager_->Reset();
    }
}

std::string WhisperEngine::GetStatus() const {
    std::string status = "Whisper Engine Status:\n";
    status += "  Initialized: " + std::string(is_ready_ ? "Yes" : "No") + "\n";
    status += "  Models Loaded: " + std::string(models_loaded_ ? "Yes" : "No") + "\n";
    status += "  Config - Layers: " + std::to_string(config_.num_layers) + "\n";
    status += "  Config - Heads: " + std::to_string(config_.num_heads) + "\n";
    status += "  Config - Head Dim: " + std::to_string(config_.head_dim) + "\n";

    if (stats_.total_inferences > 0) {
        status += "  Total Inferences: " + std::to_string(stats_.total_inferences) + "\n";
        status += "  Total Tokens: " + std::to_string(stats_.total_tokens) + "\n";
        status += "  Avg Time: " + std::to_string(stats_.total_time_ms / stats_.total_inferences) + " ms\n";
    }

    return status;
}

std::vector<Ort::Value> WhisperEngine::RunEncoder(
    const std::vector<std::vector<float>>& input_features) {

    // 转换输入为ONNX张量
    // Shape: [1, 80, 3000] - batch=1, mel_bins=80, frames=3000
    std::vector<int64_t> shape = {1,
                                  static_cast<int64_t>(input_features.size()),
                                  static_cast<int64_t>(input_features[0].size())};

    // 转置数据: [frames, mel_bins] -> [mel_bins, frames]
    std::vector<float> transposed_data;
    transposed_data.reserve(shape[1] * shape[2]);

    for (size_t i = 0; i < input_features[0].size(); ++i) {
        for (size_t j = 0; j < input_features.size(); ++j) {
            transposed_data.push_back(input_features[j][i]);
        }
    }

    Ort::MemoryInfo memory_info = Ort::MemoryInfo::CreateCpu(
        OrtArenaAllocator, OrtMemTypeDefault);

    auto input_tensor = Ort::Value::CreateTensor<float>(
        memory_info,
        transposed_data.data(),
        transposed_data.size(),
        shape.data(),
        shape.size()
    );

    // 运行推理
    auto output_tensors = encoder_session_->Run(
        Ort::RunOptions{nullptr},
        encoder_input_names_.data(),
        &input_tensor,
        1,
        encoder_output_names_.data(),
        encoder_output_names_.size()
    );

    return output_tensors;
}

std::vector<Ort::Value> WhisperEngine::RunDecoder(
    const std::vector<int64_t>& input_ids,
    const std::vector<Ort::Value>& encoder_output,
    std::vector<Ort::Value>& kv_cache) {

    // 准备输入
    std::vector<Ort::Value> inputs;

    Ort::MemoryInfo memory_info = Ort::MemoryInfo::CreateCpu(
        OrtArenaAllocator, OrtMemTypeDefault);

    // 1. input_ids
    std::vector<int64_t> input_ids_shape = {
        1,
        static_cast<int64_t>(input_ids.size())
    };

    auto input_ids_tensor = Ort::Value::CreateTensor<int64_t>(
        memory_info,
        const_cast<int64_t*>(input_ids.data()),
        input_ids.size(),
        input_ids_shape.data(),
        input_ids_shape.size()
    );
    inputs.push_back(std::move(input_ids_tensor));

    // 2. encoder_hidden_states
    inputs.push_back(encoder_output[0]);  // 移动所有权

    // 3. past_key_values (KV Cache)
    for (auto& kv : kv_cache) {
        inputs.push_back(std::move(kv));
    }

    // 运行解码器
    auto output_tensors = decoder_session_->Run(
        Ort::RunOptions{nullptr},
        decoder_input_names_.data(),
        inputs.data(),
        inputs.size(),
        decoder_output_names_.data(),
        decoder_output_names_.size()
    );

    return output_tensors;
}

int64_t WhisperEngine::GreedyDecode(const Ort::Value& logits) {
    // 获取logits形状 [batch, vocab_size]
    auto shape = logits.GetTensorTypeAndShapeInfo().GetShape();
    int64_t vocab_size = shape[1];

    // 获取数据指针
    float* logits_data = logits.GetTensorMutableData<float>();

    // 找最大值的索引
    int64_t max_idx = 0;
    float max_val = logits_data[0];
    for (int64_t i = 1; i < vocab_size; ++i) {
        if (logits_data[i] > max_val) {
            max_val = logits_data[i];
            max_idx = i;
        }
    }

    return max_idx;
}

std::vector<int64_t> WhisperEngine::PrepareDecoderInput(
    int64_t prev_token,
    bool is_first) {

    // 对于第一次调用，返回[start_token]
    // 后续返回[prev_token]
    return {prev_token};
}

Ort::Value WhisperEngine::VectorToTensor(
    const std::vector<std::vector<float>>& data,
    const std::vector<int64_t>& shape) {

    // 展平数据
    std::vector<float> flat_data;
    flat_data.reserve(shape[0] * shape[1] * shape[2]);

    for (const auto& row : data) {
        for (const auto& val : row) {
            flat_data.push_back(val);
        }
    }

    Ort::MemoryInfo memory_info = Ort::MemoryInfo::CreateCpu(
        OrtArenaAllocator, OrtMemTypeDefault);

    return Ort::Value::CreateTensor<float>(
        memory_info,
        flat_data.data(),
        flat_data.size(),
        shape.data(),
        shape.size()
    );
}

} // namespace embedded_whisper
