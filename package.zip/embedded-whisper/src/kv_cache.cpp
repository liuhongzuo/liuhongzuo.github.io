/**
 * @file kv_cache.cpp
 * @brief KV Cache implementation for efficient autoregressive decoding
 * @description 实现Whisper模型的KV Cache管理，通过zero-copy更新和
 * 内存池预分配来优化嵌入式平台的推理性能
 */

#include "kv_cache.hpp"
#include <cstdlib>
#include <stdexcept>

namespace embedded_whisper {

KVCacheManager::KVCacheManager(Ort::Session& ort_session,
                               int num_layers,
                               int num_heads,
                               int head_dim,
                               int max_length)
    : session_(ort_session)
    , memory_info_(Ort::MemoryInfo::CreateCpu(OrtArenaAllocator, OrtMemTypeDefault))
    , num_layers_(num_layers)
    , num_heads_(num_heads)
    , head_dim_(head_dim)
    , max_length_(max_length)
    , current_length_(0)
    , k_shape_({1, num_heads, max_length, head_dim})
    , v_shape_({1, num_heads, max_length, head_dim})
    , is_initialized_(false)
{
    // 预分配内存池
    PreAllocate();
}

KVCacheManager::~KVCacheManager() {
    // 释放内存池
    for (auto* ptr : k_buffer_pool_) {
        if (ptr) free(ptr);
    }
    for (auto* ptr : v_buffer_pool_) {
        if (ptr) free(ptr);
    }
}

void KVCacheManager::PreAllocate() {
    // 为每一层预分配K和V缓冲区
    // 对于嵌入式平台，使用malloc而不是new以避免overhead
    const size_t k_size = num_heads_ * max_length_ * head_dim_ * sizeof(float);
    const size_t v_size = num_heads_ * max_length_ * head_dim_ * sizeof(float);

    for (int i = 0; i < num_layers_; ++i) {
        float* k_buf = static_cast<float*>(malloc(k_size));
        float* v_buf = static_cast<float*>(malloc(v_size));

        if (!k_buf || !v_buf) {
            throw std::runtime_error("Failed to allocate KV cache memory");
        }

        // 初始化为0
        memset(k_buf, 0, k_size);
        memset(v_buf, 0, v_size);

        k_buffer_pool_.push_back(k_buf);
        v_buffer_pool_.push_back(v_buf);
    }
}

void KVCacheManager::Initialize() {
    if (is_initialized_) {
        Reset();
        return;
    }

    // 创建空的KV Cache张量
    past_kv_cache_.clear();
    past_kv_cache_.reserve(num_layers_ * 2);  // K and V for each layer

    // 对于每一层，创建K和V张量
    for (int i = 0; i < num_layers_; ++i) {
        // Key tensor
        auto k_tensor = Ort::Value::CreateTensor<float>(
            memory_info_,
            k_buffer_pool_[i],
            k_shape_[0] * k_shape_[1] * k_shape_[2] * k_shape_[3],
            k_shape_.data(),
            k_shape_.size()
        );
        past_kv_cache_.push_back(std::move(k_tensor));

        // Value tensor
        auto v_tensor = Ort::Value::CreateTensor<float>(
            memory_info_,
            v_buffer_pool_[i],
            v_shape_[0] * v_shape_[1] * v_shape_[2] * v_shape_[3],
            v_shape_.data(),
            v_shape_.size()
        );
        past_kv_cache_.push_back(std::move(v_tensor));
    }

    current_length_ = 0;
    is_initialized_ = true;
}

std::vector<Ort::Value> KVCacheManager::GetInputCache() {
    if (!is_initialized_) {
        Initialize();
    }

    // 返回当前缓存的副本或引用
    // 对于第一次调用，返回空缓存
    if (current_length_ == 0) {
        // 创建新的空张量
        std::vector<Ort::Value> empty_cache;
        empty_cache.reserve(num_layers_ * 2);

        for (int i = 0; i < num_layers_; ++i) {
            // Key
            auto k_tensor = Ort::Value::CreateTensor<float>(
                memory_info_,
                k_buffer_pool_[i],
                k_shape_[0] * k_shape_[1] * k_shape_[2] * k_shape_[3],
                k_shape_.data(),
                k_shape_.size()
            );
            empty_cache.push_back(std::move(k_tensor));

            // Value
            auto v_tensor = Ort::Value::CreateTensor<float>(
                memory_info_,
                v_buffer_pool_[i],
                v_shape_[0] * v_shape_[1] * v_shape_[2] * v_shape_[3],
                v_shape_.data(),
                v_shape_.size()
            );
            empty_cache.push_back(std::move(v_tensor));
        }

        return empty_cache;
    }

    return past_kv_cache_;
}

void KVCacheManager::UpdateCache(std::vector<Ort::Value>& present_kv) {
    if (present_kv.empty()) {
        return;
    }

    // Zero-copy更新策略:
    // 1. 获取present_kv的原始指针
    // 2. 将这些指针直接复制到我们的缓冲区
    // 3. 不再需要销毁present_kv，因为它们是tensor views

    // 更新缓存大小
    current_length_++;

    // 交换数据而不是复制
    // 注意: present_kv的数据已经在内存池中，所以直接移动
    past_kv_cache_.clear();
    for (auto& tensor : present_kv) {
        past_kv_cache_.push_back(std::move(tensor));
    }
}

void KVCacheManager::Reset() {
    // 重置所有缓冲区为0
    const size_t k_size = num_heads_ * max_length_ * head_dim_ * sizeof(float);
    const size_t v_size = num_heads_ * max_length_ * head_dim_ * sizeof(float);

    for (int i = 0; i < num_layers_; ++i) {
        memset(k_buffer_pool_[i], 0, k_size);
        memset(v_buffer_pool_[i], 0, v_size);
    }

    past_kv_cache_.clear();
    current_length_ = 0;
    is_initialized_ = false;
}

Ort::Value KVCacheManager::CreateEmptyTensor(const std::vector<int64_t>& shape) {
    // 计算元素数量
    size_t num_elements = 1;
    for (const auto& dim : shape) {
        num_elements *= dim;
    }

    // 分配内存
    std::vector<float> data(num_elements, 0.0f);

    return Ort::Value::CreateTensor<float>(
        memory_info_,
        data.data(),
        num_elements,
        shape.data(),
        shape.size()
    );
}

} // namespace embedded_whisper
