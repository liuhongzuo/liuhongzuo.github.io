/**
 * @file main.cpp
 * @brief Embedded Whisper Inference - Main Entry Point
 * @description 嵌入式平台Whisper-tiny推理程序入口
 * 支持命令行参数和交互模式
 */

#include <iostream>
#include <memory>
#include <string>
#include <vector>
#include <cstring>
#include <chrono>

#include "whisper_engine.hpp"

using namespace embedded_whisper;

/**
 * @brief 打印使用说明
 */
void PrintUsage(const char* program_name) {
    std::cout << "Usage: " << program_name << " [options] <audio_file>\n\n";
    std::cout << "Options:\n";
    std::cout << "  -h, --help              Show this help message\n";
    std::cout << "  -m, --model-dir <dir>   Model directory (default: ./models)\n";
    std::cout << "  -t, --threads <n>       Number of threads (default: 1)\n";
    std::cout << "  --max-len <n>           Maximum tokens (default: 448)\n";
    std::cout << "  --temperature <t>       Temperature (default: 0.0)\n";
    std::cout << "  -v, --verbose           Verbose output\n";
    std::cout << "\n";
    std::cout << "Example:\n";
    std::cout << "  " << program_name << " -t 2 audio.wav\n";
}

/**
 * @brief 打印推理结果
 */
void PrintResult(const InferenceResult& result, bool verbose) {
    std::cout << "\n=== Transcription Result ===\n";
    std::cout << "Text: " << result.text << "\n";

    if (verbose) {
        std::cout << "Tokens: " << result.num_tokens_generated << "\n";
        std::cout << "Token IDs: [";
        for (size_t i = 0; i < result.tokens.size(); ++i) {
            if (i > 0) std::cout << ", ";
            std::cout << result.tokens[i];
        }
        std::cout << "]\n";
    }

    std::cout << "Inference Time: " << result.inference_time_ms << " ms\n";
    if (result.num_tokens_generated > 0) {
        std::cout << "Tokens/sec: "
                  << (result.num_tokens_generated * 1000.0 / result.inference_time_ms)
                  << "\n";
    }
    std::cout << "================================\n";
}

/**
 * @brief 主函数
 */
int main(int argc, char* argv[]) {
    // 解析命令行参数
    std::string model_dir = "./models";
    std::string audio_file;
    int num_threads = 1;
    int max_tokens = 448;
    float temperature = 0.0f;
    bool verbose = false;

    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];

        if (arg == "-h" || arg == "--help") {
            PrintUsage(argv[0]);
            return 0;
        }
        else if (arg == "-m" || arg == "--model-dir") {
            if (i + 1 < argc) {
                model_dir = argv[++i];
            }
        }
        else if (arg == "-t" || arg == "--threads") {
            if (i + 1 < argc) {
                num_threads = std::stoi(argv[++i]);
            }
        }
        else if (arg == "--max-len") {
            if (i + 1 < argc) {
                max_tokens = std::stoi(argv[++i]);
            }
        }
        else if (arg == "--temperature") {
            if (i + 1 < argc) {
                temperature = std::stof(argv[++i]);
            }
        }
        else if (arg == "-v" || arg == "--verbose") {
            verbose = true;
        }
        else {
            // 假设是音频文件
            audio_file = arg;
        }
    }

    // 检查必需参数
    if (audio_file.empty()) {
        std::cerr << "Error: No audio file specified\n\n";
        PrintUsage(argv[0]);
        return 1;
    }

    std::cout << "Embedded Whisper Inference Engine\n";
    std::cout << "===================================\n";
    std::cout << "Audio file: " << audio_file << "\n";
    std::cout << "Model dir: " << model_dir << "\n";
    std::cout << "Threads: " << num_threads << "\n";
    std::cout << "Max tokens: " << max_tokens << "\n";
    std::cout << "Temperature: " << temperature << "\n\n";

    // 配置Whisper
    WhisperConfig config;
    config.encoder_model_path = model_dir + "/encoder.onnx";
    config.decoder_model_path = model_dir + "/decoder.onnx";
    config.num_threads = num_threads;
    config.max_tokens = max_tokens;
    config.temperature = temperature;

    // 创建引擎
    std::cout << "Initializing Whisper engine...\n";
    WhisperEngine engine(config);

    // 初始化
    if (!engine.Initialize()) {
        std::cerr << "Error: Failed to initialize engine\n";
        std::cerr << "Please check:\n";
        std::cerr << "  1. Model files exist in " << model_dir << "\n";
        std::cerr << "  2. ONNX Runtime is properly installed\n";
        std::cerr << "  3. Sufficient memory available\n";
        return 1;
    }

    std::cout << "Engine initialized successfully!\n\n";

    // 打印引擎状态
    if (verbose) {
        std::cout << engine.GetStatus() << "\n";
    }

    // 运行推理
    std::cout << "Running inference...\n";
    auto start = std::chrono::high_resolution_clock::now();

    try {
        auto result = engine.InferFromFile(audio_file);
        auto end = std::chrono::high_resolution_clock::now();

        auto total_time = std::chrono::duration<double, std::milli>(
            end - start).count();

        // 打印结果
        PrintResult(result, verbose);

        std::cout << "Total time (including audio loading): " << total_time << " ms\n";

    } catch (const std::exception& e) {
        std::cerr << "Error during inference: " << e.what() << "\n";
        return 1;
    }

    return 0;
}
